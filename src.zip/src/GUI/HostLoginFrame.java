package GUI;

import Resource.StringValue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import GUI.Listener.HostLoginFrameBackButtonActionListener;
import GUI.Listener.HostLoginFrameStartButtonActionListener;

public class HostLoginFrame {
	
	public JPanel					hostLoginPanel;
	public JFrame					hostLoginFrame;
	
	public JLabel					hostNameLabel;
	public JLabel					portLabel;
	//public JLabel					goodGuyNumLabel;
	//public JLabel					badGuyNumLabel;
	
	public JTextField				hostNameTextField;
	public JTextField				portTextField;
	//public JTextField				goodGuyNumTextField;
	//public JTextField				badGuyNumTextField;
	
	public JButton					startGameButton;
	public JButton					backButton;
	
	public void run(){
		//---------------------Panel-----------------------------//
		// Components in the panel:
		hostNameLabel = new JLabel(StringValue.YOUR_NAME_LABEL);
		portLabel = new JLabel(StringValue.PORT_LABEL);
		//goodGuyNumLabel = new JLabel(StringValue.GOOD_GUY_NUM_LABEL);
		//badGuyNumLabel = new JLabel(StringValue.BAD_GUY_NUM_LABEL);
		
		hostNameTextField = new JTextField(null, 20);
		portTextField = new JTextField("12345", 20);
		//goodGuyNumTextField = new JTextField(null, 20);
		//badGuyNumTextField = new JTextField(null, 20);
		
		startGameButton = new JButton(StringValue.START_GAME_BUTTON);
		backButton = new JButton(StringValue.BACK_BUTTON);
		
		// Panel:
		hostLoginPanel = new JPanel();
		
		hostLoginPanel.add(hostNameLabel);
		hostLoginPanel.add(hostNameTextField);
		hostLoginPanel.add(portLabel);
		hostLoginPanel.add(portTextField);
		//hostLoginPanel.add(goodGuyNumLabel);
		//hostLoginPanel.add(goodGuyNumTextField);
		//hostLoginPanel.add(badGuyNumLabel);
		//hostLoginPanel.add(badGuyNumTextField);
		hostLoginPanel.add(startGameButton);
		hostLoginPanel.add(backButton);
		
		//----------------------Frame-----------------------------//
		hostLoginFrame = new JFrame(StringValue.HOST_LOGIN_FRAME);
		hostLoginFrame.setContentPane(hostLoginPanel);
		hostLoginFrame.pack();
		hostLoginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		hostLoginFrame.setResizable(false);
		hostLoginFrame.setVisible(true);
		
		
		HostLoginFrameStartButtonActionListener startGameButtonActionListener = new HostLoginFrameStartButtonActionListener(this);
		startGameButton.addActionListener(startGameButtonActionListener);
		
		HostLoginFrameBackButtonActionListener backButtonActionListener = new HostLoginFrameBackButtonActionListener(this);
		backButton.addActionListener(backButtonActionListener);
		
	
		
	}
}