package GUI;

public class PlayerBanStatus {
	
	public int id;
	public String playerName;
	public int axe;
	public int lamp;
	public int helmet;
	
	public PlayerBanStatus ( int id , String playerName )
	{
		this.id = id;
		this.playerName = playerName;
		this.axe = 0;
		this.lamp = 0;
		this.helmet = 0;
	}

}
