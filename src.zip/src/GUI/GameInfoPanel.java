package GUI;
import Networking.Host;

import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;


public class GameInfoPanel extends JPanel {
	private static JSplitPane                    mainSplitPane;
	//private static JSplitPane                    rightSplitPane;
	private static JSplitPane                    rightSplit2Pane;
	public JTextArea gameLogTextArea;
	//public int num_of_card_left;

	public JLabel cardLeftLablel;
	public JLabel identityLabel;
	public JLabel								countDown;
	
	public GameInfoPanel() {
		
		countDown = new JLabel();
		identityLabel = new JLabel();
		//banStatus = new JLabel("BAN:AXE(0),LAMP(0),HELMET(0)");
		gameLogTextArea = new JTextArea();
		gameLogTextArea.setLineWrap(true);
		gameLogTextArea.setWrapStyleWord(true);
		gameLogTextArea.setEditable(false);
		DefaultCaret caret = (DefaultCaret)gameLogTextArea.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		JScrollPane gameLogScrollPane = new JScrollPane(gameLogTextArea);
		
		//gameLogScrollPane.setPreferredSize(new Dimension(505,50));
		//gameLogScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
		cardLeftLablel = new JLabel("Card Left: ");
		cardLeftLablel.setHorizontalAlignment(JLabel.CENTER);
		cardLeftLablel.setPreferredSize(new Dimension(100,200));
		// Construct the main split pane (left & right area)
		mainSplitPane = new JSplitPane();
		mainSplitPane.setEnabled(false);
		mainSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		mainSplitPane.setDividerSize(5);
		mainSplitPane.setDividerLocation(50);
		mainSplitPane.setPreferredSize(new Dimension(290, 180));
		
		// Add components into the left area
		mainSplitPane.setRightComponent(gameLogScrollPane);
		
		JSplitPane countDownAndCardLeftPane = new JSplitPane();
		countDownAndCardLeftPane.setEnabled(false);
		countDownAndCardLeftPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
		countDownAndCardLeftPane.setDividerSize(5);
		countDownAndCardLeftPane.setDividerLocation(35);
		countDownAndCardLeftPane.setLeftComponent(countDown);
		countDownAndCardLeftPane.setRightComponent(cardLeftLablel);
		// Construct the right split pane (upper and lower)
		rightSplit2Pane = new JSplitPane();
		rightSplit2Pane.setEnabled(false);
		rightSplit2Pane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
		rightSplit2Pane.setDividerSize(5);
		rightSplit2Pane.setDividerLocation(230);
		
        rightSplit2Pane.setLeftComponent(countDownAndCardLeftPane);
        rightSplit2Pane.setRightComponent(identityLabel);
		
        // Construct the right split pane (upper and lower)
        //rightSplitPane = new JSplitPane();
        //rightSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
       // rightSplitPane.setDividerSize(5);
       // rightSplitPane.setDividerLocation(50);
        
        // Add components into the right area
       // rightSplitPane.setLeftComponent(rightSplit2Pane);
       // rightSplitPane.setRightComponent(banStatus);
        mainSplitPane.setLeftComponent(rightSplit2Pane);
        
        add(mainSplitPane);
	}
	public void refresh()
	{
		gameLogTextArea.setText("");
		cardLeftLablel.setText("");
		countDown.setText("");
		identityLabel.setIcon(null);
		
	}
}