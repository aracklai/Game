package GUI;

import Resource.StringValue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import GUI.Listener.GuestLoginFrameBackButtonActionListener;
import GUI.Listener.GuestLoginFrameStartButtonActionListener;

public class GuestLoginFrame {
	
	public JPanel					guestLoginPanel;
	public JFrame					guestLoginFrame;
	
	public JLabel					guestNameLabel;
	public JLabel					ipLabel;
	public JLabel					portLabel;
	
	public JTextField				guestNameTextField;
	public JTextField				ipTextField;
	public JTextField				portTextField;
	
	public JButton					startGameButton;
	public JButton					backButton;
	
	public void run(){
		//---------------------Panel-----------------------------//
		// Components in the panel:
		guestNameLabel = new JLabel(StringValue.YOUR_NAME_LABEL);
		ipLabel = new JLabel(StringValue.IP_LABEL);
		portLabel = new JLabel(StringValue.PORT_LABEL);
		
		guestNameTextField = new JTextField(null, 20);
		ipTextField = new JTextField("localhost", 20);
		portTextField = new JTextField("12345", 20);
		
		startGameButton = new JButton(StringValue.START_GAME_BUTTON);
		backButton = new JButton(StringValue.BACK_BUTTON);
		
		// Panel:
		guestLoginPanel = new JPanel();
		
		guestLoginPanel.add(guestNameLabel);
		guestLoginPanel.add(guestNameTextField);
		guestLoginPanel.add(ipLabel);
		guestLoginPanel.add(ipTextField);
		guestLoginPanel.add(portLabel);
		guestLoginPanel.add(portTextField);
		
		guestLoginPanel.add(startGameButton);
		guestLoginPanel.add(backButton);
		
		//----------------------Frame-----------------------------//
		guestLoginFrame = new JFrame(StringValue.GUEST_LOGIN_FRAME);
		guestLoginFrame.setContentPane(guestLoginPanel);
		guestLoginFrame.setSize(250,270);
		guestLoginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		guestLoginFrame.setResizable(false);
		guestLoginFrame.setVisible(true);
		
		GuestLoginFrameStartButtonActionListener startGameButtonActionListener = new GuestLoginFrameStartButtonActionListener(this);
		startGameButton.addActionListener(startGameButtonActionListener);
		
		
		GuestLoginFrameBackButtonActionListener backButtonActionListener = new GuestLoginFrameBackButtonActionListener(this);
		backButton.addActionListener(backButtonActionListener);
		
	
		
	}
}
