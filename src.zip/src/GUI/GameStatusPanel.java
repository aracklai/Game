package GUI;

import java.awt.Dimension;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Resource.ImageValue;

public class GameStatusPanel extends JPanel {
	
	public GameStatusPanel()
	{
		
		JLabel characterLabel = new JLabel();
		characterLabel.setPreferredSize(new Dimension(150,100));
		add(characterLabel);
		Image img = new ImageValue().getImage(-1,ImageValue.MAP_CARD_DIMENSION);
		characterLabel.setIcon( new ImageIcon (img));
		
	}

}
