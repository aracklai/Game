package GUI;

import Resource.StringValue;

import javax.swing.JFrame;

import GameEngine.Card;
import GameEngine.CardInformation;
import GameEngine.SuffleCard;

public class InitFrame {
	
	static JFrame window = new JFrame(StringValue.WINDOW_NAME);
	
	public void run()
	
	{
		window.setContentPane(new InitFramePanel());
		//window.setContentPane(new MapPanel());
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.pack();
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		//Card[] cards = new SuffleCard().start();
		//for ( int i = 0; i < cards.length; i ++)
		//{
		//	if ( cards[i].type == 0 )
		//	System.out.println( "type:" + cards[i].type + ", id :" + cards[i].id);
		//}
		
	}

}
