package GUI;

import GUI.Listener.RestartMenuItemActionListener;
import GUI.Listener.StartMenuItemActionListener;
import GUI.Listener.SurrenderMenuItemActionListener;
import Networking.Client;
import Networking.Entity;
import Networking.Host;
import Networking.Message.LeaveMessage;
import Resource.StringValue;


import java.awt.BorderLayout;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

public class GameFrame implements WindowListener{
	
	int mode;
	public Entity entity;
	public static final int HOST_MODE = 0;
	public static final int CLIENT_MODE = 1;
	
	//The Frame
	private static JFrame                        frame;
	private static JSplitPane                    mainSplitPane;
	private static JSplitPane                    leftSplitPane;
	private static JSplitPane                    left1SplitPane;
	private static JSplitPane                    rightSplitPane;
	
	//th menu bar
	JMenuBar menuBar;
	JMenu actionMenu;
	JMenuItem startMenuItem;
	JMenuItem restartMenuItem;
	JMenuItem surrenderMenuItem;
//	private static 	JPanel		panel1 = new JPanel();
//	private	static	JPanel		panel2 = new JPanel();
	//private	static	JPanel		panel3 = new JPanel();
	//private	static	JPanel		panel4 = new JPanel();
	//private	static	JPanel		panel5 = new JPanel();
	
	public HandCardPanel						handCardPanel;
	public MapPanel								mapPanel; 
	public ConversationPanel					conversationPanel; 
	public GameInfoPanel						gameInfoPanel;
	public GameChairPanel gameChairPanel;
	
	
	
	public GameFrame( int mode )
	{
		this.mode = mode;
		//if ( )
		
	}
	public void run(){
		
		handCardPanel = new HandCardPanel(this);
		mapPanel = new MapPanel(this);
		gameInfoPanel = new GameInfoPanel();
		gameChairPanel = new GameChairPanel(this);
		conversationPanel = new ConversationPanel(this);
		
		
		menuBar = new JMenuBar();
		
		actionMenu = new JMenu("Action");
		startMenuItem = new JMenuItem("Start");
		restartMenuItem = new JMenuItem("Refresh");
		surrenderMenuItem = new JMenuItem("Surrender");
		startMenuItem.addActionListener( new StartMenuItemActionListener(entity));
		restartMenuItem.addActionListener( new RestartMenuItemActionListener(entity));
		surrenderMenuItem.addActionListener(new SurrenderMenuItemActionListener(entity) );
		if ( mode == GameFrame.HOST_MODE )
		{
			actionMenu.add(startMenuItem);
			actionMenu.add(restartMenuItem);
		}
		actionMenu.add(surrenderMenuItem);
		
		menuBar.add(actionMenu);
		
		
		
		frame = new JFrame(StringValue.GAME_FRAME_NAME);
		frame.addWindowListener(this);
		frame.setJMenuBar(menuBar);
		frame .setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setSize(760, 480);
		frame.setResizable(false);
		// Construct the main split pane (left & right)
				mainSplitPane = new JSplitPane();
				mainSplitPane.setEnabled(false);
				mainSplitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
				mainSplitPane.setDividerSize(5);
				mainSplitPane.setDividerLocation(482);
				frame.getContentPane().add(mainSplitPane, BorderLayout.CENTER);
				
		        // Construct the left split pane (upper and lower)
				leftSplitPane = new JSplitPane();
				leftSplitPane.setEnabled(false);
				leftSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
				leftSplitPane.setDividerSize(5);
				leftSplitPane.setDividerLocation(230);
				leftSplitPane.setLeftComponent(gameChairPanel);
				//leftSplitPane.setRightComponent(handCardPanel);
				mainSplitPane.setLeftComponent(leftSplitPane);
				
				
		        // Construct the left split pane (upper and lower)
				left1SplitPane = new JSplitPane();
				left1SplitPane.setEnabled(false);
				left1SplitPane.setOrientation(JSplitPane.HORIZONTAL_SPLIT);
				left1SplitPane.setDividerSize(5);
				left1SplitPane.setDividerLocation(295);
				left1SplitPane.setLeftComponent(gameInfoPanel);
				left1SplitPane.setRightComponent(handCardPanel);
				leftSplitPane.setRightComponent(left1SplitPane);

		        // Construct the right split pane (upper and lower)
		        rightSplitPane = new JSplitPane();
		        rightSplitPane.setEnabled(false);
		        rightSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		        rightSplitPane.setDividerSize(5);
		        rightSplitPane.setDividerLocation(320);
		        rightSplitPane.setLeftComponent(mapPanel);
		        rightSplitPane.setRightComponent(conversationPanel);
		        mainSplitPane.setRightComponent(rightSplitPane);
		        
				frame.setVisible(true);
			}
			
			public void setEntity ( Entity e )
			{
				this.entity = e;
			}
			@Override
			public void windowActivated(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void windowClosed(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void windowClosing(WindowEvent arg0) {
				if ( mode == GameFrame.CLIENT_MODE )
				{
					Client c = (Client) entity;
					c.sentToHost( new LeaveMessage( c.id , c.name ,c.seatLocation) );
				}
				else if ( mode == GameFrame.HOST_MODE )
				{
					Host gs = (Host) entity;
					gs.sendToAllClient( new LeaveMessage( gs.id , gs.name ,gs.seatLocation) );
				}
				
			}
			@Override
			public void windowDeactivated(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void windowDeiconified(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void windowIconified(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void windowOpened(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
		}

