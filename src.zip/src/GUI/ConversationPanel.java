package GUI;

import java.awt.Dimension;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.StyledDocument;

import GUI.Listener.ConversationPanelActionListener;


public class ConversationPanel extends JPanel{

	public JScrollPane				textLogScrollPane;
	public JTextPane				textLogArea;
	public String					textLog;
	
	public StyledDocument 			doc;
	
	public JTextField				enterTextField;
	public String					enteredString;
	public GameFrame				gf;
	
	public ConversationPanel(GameFrame gf) {
		this.gf = gf;
		
		BoxLayout boxLayout = new BoxLayout(this, BoxLayout.Y_AXIS);
		this.setLayout(boxLayout);
		
		textLogArea = new JTextPane();
		textLogArea.setEditable(false);
		textLogArea.setCaretPosition(textLogArea.getDocument().getLength()); 
		
		doc = textLogArea.getStyledDocument();
		
		textLogScrollPane = new JScrollPane(textLogArea);
		textLogScrollPane.setPreferredSize(new Dimension(505,164));
		textLogScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
//		DefaultCaret gameCommunicationCaret = (DefaultCaret)textLogArea.getCaret();
//		gameCommunicationCaret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		add(textLogScrollPane);
		enterTextField = new JTextField(null, 46);
		add(enterTextField);
		
		ConversationPanelActionListener enterTextFieldListener = new ConversationPanelActionListener(this.gf, doc);
		enterTextField.addActionListener(enterTextFieldListener);
		
		
	}
	
}
