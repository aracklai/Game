package GUI;

import Resource.StringValue;

import GUI.InitFrame;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JPanel;

public class InitFramePanel extends JPanel implements ActionListener {
	
	private static final long serialVersionUID = 5668546656808952892L;
	
	//dimensions
	public static final int WIDTH = 320;
	public static final int HEIGHT = 240;
	public static final int SCALE = 2;
	
	//image 
	private BufferedImage image;
	
	//Component
	public JButton bStartAsHost = new JButton(StringValue.HOST_BUTTON);
	public JButton bStartAsJoin = new JButton(StringValue.JOIN_BUTTON);
	public JButton bExit = new JButton(StringValue.EXIT_BUTTON);
	
	
	public InitFramePanel(){
		super();
		setLayout(null);
		setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
		add(bStartAsHost);
		add(bStartAsJoin);
		add(bExit);
		bStartAsHost.setBounds(450,340,60,30);
		bStartAsJoin.setBounds(450,380,60,30);
		bExit.setBounds(450,420,60,30);
		
		bStartAsHost.addActionListener(this);
		bStartAsJoin.addActionListener(this);
		bExit.addActionListener(this);
		
	}
	
	
	public void paintComponent(Graphics g) {
		
		try{
			image = ImageIO.read(getClass().getResource("/Background/dig_gold_bg.jpg"));

		}catch(Exception e){
			e.printStackTrace();
		}
	    super.paintComponent(g);
				g.drawImage(image, 0,0, WIDTH * 2, HEIGHT * 2, null);
	}


	public void actionPerformed(ActionEvent e) {
	      if(e.getSource() == bStartAsHost)
	      {
	    	  System.out.print("You clicked Host\n");
	    	  InitFrame.window.dispose();
	    	  new HostLoginFrame().run();
	      }
	      else if (e.getSource() == bStartAsJoin)
	      {
	    	  System.out.print("You click Join\n");
	    	  InitFrame.window.dispose();
	    	  new GuestLoginFrame().run();
	      }
	      else
	      {
	    	  InitFrame.window.dispose();
//	      	  System.exit(0);
	      }
	    	  
	}
}
