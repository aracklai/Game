package GUI;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import GUI.Listener.MapPanelButtonActionListener;
import Resource.ImageValue;

public class MapPanel extends JPanel {
	public JButton[][] buttons;
	public MapPanel(GameFrame gf)
	{
		GridLayout mapGridLayout = new GridLayout(9,5);
		this.setLayout(mapGridLayout);
		ImageValue iv = new ImageValue();
		buttons = new JButton[9][5];
		
		

			for ( int j = 0; j < 45; j++ )
			{
				JButton test = new JButton ();
				buttons[j/5][j%5] = test;
			
			
				if ( j == 42)
				{
					Image img = iv.getImage(0,ImageValue.MAP_CARD_DIMENSION);
					
					
					test.setIcon(new ImageIcon(img));
				}
				test.setMargin(new Insets(0, 0, 0, 0));
				test.setPreferredSize(new Dimension(300/6,200/6));
				MapPanelButtonActionListener mapPanelButtonActionListener = new MapPanelButtonActionListener(gf,j/5, j%5);
				test.addActionListener(mapPanelButtonActionListener);
				add(test);
			}
		//} 
			//this.setPreferredSize(new Dimension(2000,2000));
		
	}
	public void refresh()
	{
		for ( int i = 0; i < 45 ; i++ )
		{
			buttons[i/5][i%5].setIcon(null);
			if ( i== 42)
			{
				ImageValue iv = new ImageValue();
				Image img = iv.getImage(0,ImageValue.MAP_CARD_DIMENSION);
				
				
				buttons[i/5][i%5].setIcon(new ImageIcon(img));
			}
		}
	}

}
