package GUI;

import java.awt.Image;
import java.awt.Insets;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import GUI.Listener.PlayerButtonActionListener;
import Resource.ImageValue;

public class GameChairPanel extends JPanel{
	
	public JButton player1;
	public JButton player2;
	public JButton player3;
	public JButton player4;
	public JButton player5;
	public JButton player6;
	public JButton player7;
	public JButton player8;
	public JButton player9;
	public JButton player10;
	public JButton[] playerButtons;
	public JLabel playerStatus;
	//public JScrollPane jp;
	public MyTableModel mtm;
	public GameChairPanel( GameFrame gf ){
		playerButtons = new JButton[10];
		player1 = new JButton();
		player1.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[0] = player1;
		
		player2 = new JButton();
		player2.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[1] = player2;
		
		
		player3 = new JButton();
		player3.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[2] = player3;
		
		player4 = new JButton();
		player4.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[3] = player4;
		
		
		player5 = new JButton();
		player5.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[4] = player5;
		
		player6 = new JButton();
		player6.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[5] = player6;
		
		player7 = new JButton();
		player7.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[6] = player7;
		
		player8 = new JButton();
		player8.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[7] = player8;
		
		player9 = new JButton();
		player9.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[8] = player9;
		
		player10 = new JButton();
		player10.setMargin(new Insets(0, 0, 0, 0));
		playerButtons[9] = player10;
		
		playerStatus = new JLabel();
		Image img =  new ImageValue().getImage(777,ImageValue.TABLE_DIMENSION);
		playerStatus.setIcon( new ImageIcon (img));
		
		this.setLayout(null);

		this.add(playerStatus);
		this.add(player1);
		this.add(player2);
		this.add(player3);
		this.add(player4);
		this.add(player5);	
		this.add(player6);
		this.add(player7);
		this.add(player8);
		this.add(player9);
		this.add(player10);	
		
		
		//ArrayList<PlayerBanStatus> testList = new ArrayList<PlayerBanStatus>();
		//testList.add( new PlayerBanStatus ("arack"));
		mtm = new MyTableModel();
		//mtm.addRow();
		JTable theTable = new JTable( mtm);
		JScrollPane jp = new JScrollPane(theTable);
		//jp.setBounds(70,15,50,30);
		this.add( jp) ;
		//mtm.addRow();
		
		int offset = 20;
		int offsetX = -5;
		playerStatus.setBounds(70+offsetX,50+offset,160,75);
		player1.setBounds(70+offsetX,15+offset,50,30);
		player2.setBounds(125+offsetX,15+offset,50,30);
		player3.setBounds(180+offsetX,15+offset,50,30);
		jp.setBounds( 290 ,15 , 180,200);

		player8.setBounds(70+offsetX,130+offset,50,30);
		player7.setBounds(125+offsetX,130+offset,50,30);
		player6.setBounds(180+offsetX,130+offset,50,30);

		player10.setBounds(15+offsetX,50+offset,50,30);
		player9.setBounds(15+offsetX,95+offset,50,30);

		player4.setBounds(235+offsetX,50+offset,50,30);
		player5.setBounds(235+offsetX,95+offset,50,30);
		
		
		player1.addActionListener(new PlayerButtonActionListener(gf,0));
		player2.addActionListener(new PlayerButtonActionListener(gf,1));
		player3.addActionListener(new PlayerButtonActionListener(gf,2));
		player4.addActionListener(new PlayerButtonActionListener(gf,3));
		player5.addActionListener(new PlayerButtonActionListener(gf,4));
		player6.addActionListener(new PlayerButtonActionListener(gf,5));
		player7.addActionListener(new PlayerButtonActionListener(gf,6));
		player8.addActionListener(new PlayerButtonActionListener(gf,7));
		player9.addActionListener(new PlayerButtonActionListener(gf,8));
		player10.addActionListener(new PlayerButtonActionListener(gf,9));
		
	}
	public void refresh()
	{
		for ( int i = 0; i < 10 ; i++ )
		{
			playerButtons[i].setBorder(UIManager.getBorder("Button.border"));
			//mtm.refresh();
		}
	}
} 