package GUI;

import Resource.ImageValue;
import Resource.StringValue;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

import GUI.Listener.HandCardPanelDiscardButtonActionListener;
import GUI.Listener.HandCardPanelHandCardButtonActionListener;
import GUI.Listener.HandCardPanelRotateButtonActionListener;
import GameEngine.Card;
import GameEngine.CardInformation;
import GameEngine.SuffleCard;


public class HandCardPanel extends JPanel {

	public JFrame				frame;
	public JPanel				handCardPanel;
	public JPanel				CardPanel;
	public JPanel				cardPanel1;
	public JPanel				cardPanel2;
	public JPanel				cardPanel3;
	public JPanel				cardPanel4;
	
	public JButton				handCardButton1;
	public JButton				handCardButton2;
	public JButton				handCardButton3;
	public JButton				handCardButton4;
	
	public JButton				rotateButton;
	
	public JButton				discardButton;
	
	public boolean 				A = false;
	public boolean 				B = false;
	public boolean 				C = false;
	public boolean 				D = false;
	
	public GameFrame gf;
	public HandCardPanel ( GameFrame gf ){

		this.gf = gf;
		GridLayout gridlayout = new GridLayout(3,2);
		this.setLayout(gridlayout);

		handCardButton1 = new JButton();
		handCardButton2 = new JButton();
		handCardButton3 = new JButton();
		handCardButton4 = new JButton();
		
		
		
		
		handCardButton1.setPreferredSize(new Dimension(150/2,100/2));
		handCardButton2.setPreferredSize(new Dimension(150/2,100/2));
		handCardButton3.setPreferredSize(new Dimension(150/2,100/2));
		handCardButton4.setPreferredSize(new Dimension(150/2,100/2));
		
		rotateButton = new JButton(StringValue.ROTATE_BUTTON);
		discardButton = new JButton(StringValue.DISCARD_BUTTON);
		
		add(handCardButton1);
		add(handCardButton2);
		add(handCardButton3);
		add(handCardButton4);
		add(rotateButton);
		add(discardButton);
		
		HandCardPanelHandCardButtonActionListener buttonActionListener = new HandCardPanelHandCardButtonActionListener(this);
		handCardButton1.addActionListener(buttonActionListener);
		handCardButton2.addActionListener(buttonActionListener);
		handCardButton3.addActionListener(buttonActionListener);
		handCardButton4.addActionListener(buttonActionListener);
		
		HandCardPanelRotateButtonActionListener handCardPanelRotateButtonActionListener = new HandCardPanelRotateButtonActionListener(gf);
		rotateButton.addActionListener(handCardPanelRotateButtonActionListener);
		
		HandCardPanelDiscardButtonActionListener handCardPanelDiscardButtonActionListener = new HandCardPanelDiscardButtonActionListener(gf);
		discardButton.addActionListener(handCardPanelDiscardButtonActionListener);
	}
	public void refresh()
	{
		handCardButton1.setIcon(null);
		handCardButton2.setIcon(null);
		handCardButton3.setIcon(null);
		handCardButton4.setIcon(null);
	}

}
