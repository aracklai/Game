package GUI;

import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class MyTableModel extends AbstractTableModel{

	private ArrayList<PlayerBanStatus> playerBanStatues;
	private String[] columnNames = { "Player" , "Axe" , "Lamp" , "Helmet" };
	
	public MyTableModel()
	{
		this.playerBanStatues = new ArrayList<PlayerBanStatus>();
	}
	public MyTableModel( ArrayList<PlayerBanStatus> playerBanStatues )
	{
		this.playerBanStatues = playerBanStatues;
	}
	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return playerBanStatues.size();
	}

	@Override
	public Object getValueAt(int row, int column) {
		
		//System.err.println("getValueAt is called");
		// TODO Auto-generated method stub
		if ( column == 0)
		{
			return playerBanStatues.get(row).playerName;
		}
		else if ( column == 1)
		{
			return playerBanStatues.get(row).axe;
		}
		else if ( column == 2)
		{
			return playerBanStatues.get(row).lamp;
		}
		else if ( column == 3)
		{
			return playerBanStatues.get(row).helmet;
		}
		return null;
	}
	public void addRow( PlayerBanStatus pbs)
	{
		//PlayerBanStatus pbs  = playerBanStatues.get(0);
		
		int size = playerBanStatues.size();
		playerBanStatues.add( pbs);
        fireTableRowsInserted(size,size);
	}
	public void update ( int id, int axe, int lamp , int helmet )
	{
		
		for ( int i =  0 ; i < playerBanStatues.size() ; i++ )
		{
			if ( playerBanStatues.get(i).id == id)
			{
				playerBanStatues.get(i).axe = axe;
				playerBanStatues.get(i).lamp = lamp;
				playerBanStatues.get(i).helmet = helmet;
				fireTableRowsInserted(0,playerBanStatues.size());
				break;
			}
		}
		
	}
	//public void setValue ( int seatLocation)
	public String getColumnName(int columnIndex) {
	    //System.out.println("in");
	    return columnNames[columnIndex];
	}
	
	public void refresh()
	{
		this.playerBanStatues = new ArrayList<PlayerBanStatus>();
	}
}
