package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GuestLoginFrame;
import GUI.InitFrame;

public class GuestLoginFrameBackButtonActionListener implements ActionListener{

	private GuestLoginFrame parent;
	public GuestLoginFrameBackButtonActionListener(GuestLoginFrame guestLoginFrame){
		parent = guestLoginFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.print("You clicked Back!\n");
		parent.guestLoginFrame.dispose();
		new InitFrame().run();
		
	}
}
