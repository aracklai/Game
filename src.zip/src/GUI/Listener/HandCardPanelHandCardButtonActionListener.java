package GUI.Listener;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.UIManager;
import javax.swing.border.Border;

import GUI.HandCardPanel;

public class HandCardPanelHandCardButtonActionListener implements ActionListener{

	private HandCardPanel parent;
	public HandCardPanelHandCardButtonActionListener(HandCardPanel handcardpanel) {
		parent = handcardpanel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Border border = BorderFactory.createLineBorder(Color.RED, 3);
		Border noBorder = UIManager.getBorder("Button.border");
		if(e.getSource() == parent.handCardButton1){
			if(parent.A==false){
				parent.A=true;
				parent.B=false;
				parent.C=false;
				parent.D=false;
			}else{
				parent.A=false;
				parent.B=false;
				parent.C=false;
				parent.D=false;
			}
		}
		
		if(e.getSource() == parent.handCardButton2){
			if(parent.B==false){
				parent.A=false;
				parent.B=true;
				parent.C=false;
				parent.D=false;
			}else{
				parent.A=false;
				parent.B=false;
				parent.C=false;
				parent.D=false;
			}
		}
		
		if(e.getSource() == parent.handCardButton3){
			if(parent.C==false){
				parent.A=false;
				parent.B=false;
				parent.C=true;
				parent.D=false;
			}else{
				parent.A=false;
				parent.B=false;
				parent.C=false;
				parent.D=false;
			}
		}
		
		if(e.getSource() == parent.handCardButton4){
			if(parent.D==false){
				parent.A=false;
				parent.B=false;
				parent.C=false;
				parent.D=true;
			}else{
				parent.A=false;
				parent.B=false;
				parent.C=false;
				parent.D=false;
			}
		}
		
		if(parent.A==true){
			parent.handCardButton1.setBorder(border);
		}else{
			parent.handCardButton1.setBorder(noBorder);
		}
		
		if(parent.B==true){
			parent.handCardButton2.setBorder(border);
		}else{
			parent.handCardButton2.setBorder(noBorder);
		}
		
		if(parent.C==true){
			parent.handCardButton3.setBorder(border);
		}else{
			parent.handCardButton3.setBorder(noBorder);
		}
		
		if(parent.D==true){
			parent.handCardButton4.setBorder(border);
		}else{
			parent.handCardButton4.setBorder(noBorder);
		}
		
	}

}
