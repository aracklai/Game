package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GuestLoginFrame;
import GUI.GameFrame;
import Networking.Client;

public class GuestLoginFrameStartButtonActionListener implements ActionListener{

	private GuestLoginFrame parent;
	public GuestLoginFrameStartButtonActionListener(GuestLoginFrame guestLoginFrame){
		parent = guestLoginFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.print("You clicked Start game!\n");
		parent.guestLoginFrame.dispose();
		
		GameFrame gf = new GameFrame( GameFrame.CLIENT_MODE );
		Client c = new Client(gf,Integer.parseInt(parent.portTextField.getText()),parent.guestNameTextField.getText(),parent.ipTextField.getText());
		gf.setEntity( c );
		gf.run();
		
		
		Thread t = new Thread(c);
		t.start();
	}
}
