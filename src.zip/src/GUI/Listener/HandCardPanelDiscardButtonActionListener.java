package GUI.Listener;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

import GUI.GameFrame;
import GameEngine.Card;
import GameEngine.UpdateGameGUI.UpdateCardLeft;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import GameEngine.UpdateGameGUI.UpdateHandCard;
import Networking.Client;
import Networking.Entity;
import Networking.Host;
import Networking.Message.CardLeftMessage;
import Networking.Message.DiscardMessage;
import Networking.Message.DrawANewCardRequestMessage;
import Networking.Message.FinishActionMessage;
import Resource.ImageValue;

public class HandCardPanelDiscardButtonActionListener implements ActionListener{
	
	public GameFrame gf;
	public Entity entity;
	public Card new_card;
	//public int new_card_id;
	public int num_of_card_left;
	public Image img;
	
	public HandCardPanelDiscardButtonActionListener(GameFrame gf) {
		this.gf = gf;
		this.entity = gf.entity;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		synchronized(gf.entity.actionLock)
		{
		if ( !entity.getYourTurn() || ( !gf.handCardPanel.A && !gf.handCardPanel.B && !gf.handCardPanel.C && !gf.handCardPanel.D ))
			return;
		
		System.err.println("discard button listener acquire the action lock ");
		
		if( gf.handCardPanel.A == true && entity.handCards[0] == null )
			return;
		if( gf.handCardPanel.B == true && entity.handCards[1] == null )
			return;
		if( gf.handCardPanel.C == true && entity.handCards[2] == null )
			return;
		if( gf.handCardPanel.D == true && entity.handCards[3] == null )
			return;
		if ( entity instanceof Host )
		{
			Host host = (Host) entity;
			DiscardMessage dm = new DiscardMessage(host.name);
			UpdateGameLog.update(gf, dm.message);
			host.sendToAllClient(dm);
			host.finishAction(host.findCardUsedPos());
			//if(host.ge.getCardStackSize() > 0)
			//{

				//new_card = host.ge.drawACard();
			
				//new_card_id = new_card.id;
				//num_of_card_left = host.ge.getCardStackSize();
			/*
			img = new ImageValue().getImage(new_card_id);
			
			if(gf.handCardPanel.A == true)
				gf.handCardPanel.handCardButton1.setIcon(new ImageIcon(img));
			else if(gf.handCardPanel.B == true)
				gf.handCardPanel.handCardButton2.setIcon(new ImageIcon(img));
			else if(gf.handCardPanel.C == true)
				gf.handCardPanel.handCardButton3.setIcon(new ImageIcon(img));			
			else if(gf.handCardPanel.D == true)
				gf.handCardPanel.handCardButton4.setIcon(new ImageIcon(img));			
			*/
				//System.out.println("UpdateCardLeft.put");
				//UpdateHandCard.update(gf, new_card);
			
			///}
			//else
			//{
				//UpdateHandCard.update(gf,null);
				//host.handCards[]
			//}
			//UpdateCardLeft.put(gf, num_of_card_left);
			//host.sendToAllClient(new DiscardMessage(num_of_card_left));
			
			//System.out.println(this.host.ge.cards.size());
		}
		else if ( entity instanceof Client )
		{
			Client client = (Client) entity;
			UpdateHandCard.update(gf, null,client.findCardUsedPos());
			//client.sentToHost(new DrawANewCardRequestMessage());
			client.finishAction(client.findCardUsedPos());
			client.sentToHost(new DiscardMessage(client.name));
			
		}
	}
	}
}
