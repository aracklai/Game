package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Networking.Entity;
import Networking.Host;
import Resource.StringValue;

public class RestartMenuItemActionListener implements ActionListener {

	Entity entity;
	public RestartMenuItemActionListener ( Entity entity)
	{
		this.entity = entity;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Host host = (Host) entity;
		if ( host.online )
			return;
		
		if ( !host.ge.gameEnded )
		{
			host.ge.endGame(StringValue.RESTART_MESSSAGE);
		}
		
	}
	
	

}
