package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GameEngine.UpdateGameGUI.UpdateGameLog;
import Networking.Client;
import Networking.Entity;
import Networking.Host;
import Networking.Message.SurrenderMessage;
import Networking.Message.SurrenderNotificationMessage;
import Resource.StringValue;

public class SurrenderMenuItemActionListener implements ActionListener {

	Entity e;
	public SurrenderMenuItemActionListener ( Entity e )
	{
		
		this.e = e;
			
	}
	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		System.err.println("SurrenderListener: pressed");
		if ( e.goodGuy && !e.surrendered)
		{
			System.err.println("SurrenderListener: it is a good guy, going to surrender");
		
			if ( e instanceof Client )
			{
				Client c = (Client) e;
				c.sentToHost(new SurrenderMessage());
				c.surrendered = true;
			}
			else if ( e instanceof Host )
			{
				
				Host h = (Host )e;
				if ( !h.ge.gameEnded)
				{
					int surrenderNumber = h.ge.numberOfSurrender + 1;
					String surrenderName = h.name;
					String message = surrenderName + StringValue.SURRENDER_MESSAGE + String.valueOf(surrenderNumber);
					h.sendToAllClient( new SurrenderNotificationMessage(message) );
					UpdateGameLog.update(h.gf, message);
					h.ge.incrementSurrender();
					h.surrendered = true;
					
					
					
					
					
				}
			}
		}
		
	}

}
