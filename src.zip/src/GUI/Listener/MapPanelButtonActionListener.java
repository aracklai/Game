package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.GameFrame;
import GameEngine.Card;
import GameEngine.RoadCard;
import GameEngine.ToolCard;
import GameEngine.UpdateGameGUI.PopUpMap;
import GameEngine.UpdateGameGUI.PutRoadCardOnMap;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import Networking.Client;
import Networking.Host;


import Networking.Message.PutRoadCardOnMapNotificationMessage;
import Networking.Message.PutRoadCardOnMapRequestMessage;

import Networking.Message.RemoveACardFromMapNotificationMessage;
import Networking.Message.RemoveACardFromMapRequestMessage;

import Networking.Message.UseMapNotificationMessage;
import Networking.Message.UseMapRequestMessage;
import Resource.ImageValue;
import Resource.StringValue;

public class MapPanelButtonActionListener implements ActionListener {
	private GameFrame gf;
	private int row;
	private int column;
	ImageValue iv;
	public MapPanelButtonActionListener(GameFrame gf , int row, int column){
		this.gf = gf;
		this.row = row;
		this.column = column;
		this.iv = new ImageValue();
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		synchronized(gf.entity.actionLock)// get the action lock
		{
			System.err.println("map button listener acquire the action lock ");
		System.out.print("Pressed map button ");
		if ( !gf.entity.getYourTurn() )
		{
			return;
		}
		if(!gf.handCardPanel.A && !gf.handCardPanel.B && !gf.handCardPanel.C && !gf.handCardPanel.D )
			return;
		
			Card cardSelected = null;
			
			if( gf.handCardPanel.A == true )
			{
				cardSelected = gf.entity.handCards[0];
			}
			else if ( gf.handCardPanel.B == true )
			{
				cardSelected = gf.entity.handCards[1];
			}
			else if ( gf.handCardPanel.C == true )
			{
				cardSelected = gf.entity.handCards[2];
			}
			else if ( gf.handCardPanel.D == true )
			{
				cardSelected = gf.entity.handCards[3];
			}
			
			if ( cardSelected instanceof RoadCard)
			{
				if ( gf.entity.helmetBanned > 0 || gf.entity.lampBanned > 0 || gf.entity.pickaxeBanned > 0 )
					return;
				
				RoadCard rc = (RoadCard) cardSelected;
				
				if ( gf.entity instanceof Host )
				{
					Host gs = (Host) gf.entity;
					
					if (gs.ge.ms.putOnMap(row, column, rc))
					{
						String logMessage = gs.name + StringValue.PLAYER_BUILD_ROAD;
						UpdateGameLog.update(gf, logMessage );
						PutRoadCardOnMap.put(gf,row,column, rc);
						gs.sendToAllClient(new PutRoadCardOnMapNotificationMessage( row , column ,rc , logMessage));
						gs.finishAction(gs.findCardUsedPos());
						
					}
					else 
						System.out.println("Cannot place this card!");
				}
				else
				{
					Client client = (Client) gf.entity;
					System.out.println("Client going to send a put RoadCard on Map request:");
					System.out.println("id:"+rc.id+",toUp:,"+rc.toUp+",toDown:"+rc.toDown+",toLeft:"+rc.toLeft+",toRight:" + rc.toRight);
					//UpdateHandCard.update(gf, null);
					String logMessage = client.name + StringValue.PLAYER_BUILD_ROAD;
					client.sentToHost(new PutRoadCardOnMapRequestMessage( row , column ,rc ,logMessage));
					client.getResponseFromHost();
				
				}
			}
			
			
			else if ( cardSelected instanceof ToolCard )
			{
				if ( row == 8 && column == 2)
					return;
				
				ToolCard tc = (ToolCard) cardSelected;
				
				if ( tc.function == ToolCard.FUNCTION_EXPLODE  )
				{
					if  ( row == 0 && ( column == 0 || column == 2 || column == 4 ) )
						return;
					if ( gf.entity instanceof Host )
					{
						Host host = ( Host ) gf.entity;
						if ( host.ge.ms.removeFromMap(row, column) )
						{
							
							
							RemoveACardFromMapNotificationMessage racfmm = new RemoveACardFromMapNotificationMessage( row, column,host.name);
							UpdateGameLog.update(gf, racfmm.message);
							host.sendToAllClient( racfmm);
							host.finishAction(host.findCardUsedPos());
						}
					}
					else
					{
						Client c = ( Client ) gf.entity;
						c.sentToHost( new RemoveACardFromMapRequestMessage( row, column,c.name));
						c.getResponseFromHost();
							
					}
				}
				else if ( tc.function == ToolCard.FUNCTION_WATCH && row == 0 && ( column == 0 || column == 2 || column == 4) )
				{
					if ( gf.entity instanceof Host )
					{
						Host host = ( Host ) gf.entity;
						int id = host.ge.ms.cards[row][column].id;
						host.finishAction(host.findCardUsedPos());
						
						UseMapNotificationMessage aumm = new UseMapNotificationMessage ( column,host.name);
						UpdateGameLog.update(gf, aumm.message);
						host.sendToAllClient(aumm);
						PopUpMap.popUp(id);
						
					}
					else
					{
						Client client = (Client) gf.entity;
						client.sentToHost( new UseMapRequestMessage( row ,column,client.name) );
						System.err.println("MapButtonListener:client sent a use map requestMessage");
						client.getResponseFromHost();
					}
				}
				
				
			}
		}
			
			
			
				
				
				
			
			
	
		
	
	}

}
