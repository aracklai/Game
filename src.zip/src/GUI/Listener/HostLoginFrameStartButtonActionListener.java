package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.HostLoginFrame;
import GUI.GameFrame;
import Networking.Host;
import Resource.ColorValue;

public class HostLoginFrameStartButtonActionListener implements ActionListener {
	
	private HostLoginFrame parent;
	public HostLoginFrameStartButtonActionListener(HostLoginFrame hostLoginFrame){
		parent = hostLoginFrame;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.print("You clicked Start game!\n");
		parent.hostLoginFrame.dispose();
		
		GameFrame gf = new GameFrame( GameFrame.HOST_MODE );
		Host gs = new Host( gf,Integer.parseInt(parent.portTextField.getText()), parent.hostNameTextField.getText());
		gs.setOnline(true);
		gf.setEntity(gs);
		gf.run();
		
		
		
		new Thread (gs).start();
		
	}
}
