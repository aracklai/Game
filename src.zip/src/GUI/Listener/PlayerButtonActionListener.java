package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;

import GUI.GameFrame;
import GameEngine.BanCard;
import GameEngine.ToolCard;

import GameEngine.UpdateGameGUI.UpdateBanStatus;
import GameEngine.UpdateGameGUI.UpdateBanTable;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import GameEngine.UpdateGameGUI.UpdateTableInfo;
import Networking.Client;
import Networking.Host;
import Networking.Message.BanNotificationMessage;
import Networking.Message.UpdateBanTableMessage;

import Networking.Message.BanRequestMessage;
import Resource.StringValue;

public class PlayerButtonActionListener implements ActionListener {

	private					GameFrame gf;
	private 				int seatLocation;
	
	public PlayerButtonActionListener(GameFrame gf , int seatLocation) {
		this.gf=gf;
		this.seatLocation = seatLocation;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		synchronized(gf.entity.actionLock)
		{
		System.err.println("player button listener acquire the action lock ");
		if( !gf.entity.getYourTurn() )
			return;
		
		if(!gf.handCardPanel.A && !gf.handCardPanel.B && !gf.handCardPanel.C && !gf.handCardPanel.D )
			return;
		
		
		BanCard theBanCard = null;
		
		if(gf.handCardPanel.A == true && gf.entity.handCards[0] instanceof BanCard)
		
		{
			theBanCard = (BanCard)gf.entity.handCards[0];
			System.out.println("Selected card 1 and it's a Ban Card.");
		}
		else if (gf.handCardPanel.B == true && gf.entity.handCards[1] instanceof BanCard)
		{
			theBanCard = (BanCard) gf.entity.handCards[1];
		}
		else if (gf.handCardPanel.C == true && gf.entity.handCards[2] instanceof BanCard)
		{
			theBanCard = (BanCard) gf.entity.handCards[2];
		}
		else if (gf.handCardPanel.D == true && gf.entity.handCards[3] instanceof BanCard)
		{
			theBanCard = (BanCard) gf.entity.handCards[3];
		}
		
		if(gf.entity instanceof Host)
		{
			System.err.println("PlayerButtonListener: Host going to ban people");
			Host gs = (Host)gf.entity;
			int playerId = gs.seatOccupied[seatLocation];
			Integer[] banArray = gs.ge.banMap.get(playerId);
			boolean valid = false;
			if ( theBanCard.instrument1 == BanCard.INSTRUMENT_PICKAXE || theBanCard.instrument2 == BanCard.INSTRUMENT_PICKAXE )
			{
				if ( theBanCard.function == ToolCard.FUNCTION_FORBIT)
				{
					valid = true;
					banArray[0]++;
					if ( playerId == 0 )
					{
						gs.pickaxeBanned++;
					}
				}
				else if ( theBanCard.function == ToolCard.FUNCTION_CLEAN )
				{
					if ( banArray[0] > 0)
					{
						valid = true;
						banArray[0]--;
						if ( playerId == 0 )
						{
							gs.pickaxeBanned--;
						}
					}
					
						
				}
			}
			
			if ( theBanCard.instrument1 == BanCard.INSTRUMENT_LAMP || theBanCard.instrument2 == BanCard.INSTRUMENT_LAMP )
			{
				if ( theBanCard.function == ToolCard.FUNCTION_FORBIT)
				{
					valid = true;
					banArray[1]++;
					if ( playerId == 0 )
					{
						gs.lampBanned++;
					}
				}
				else if ( theBanCard.function == ToolCard.FUNCTION_CLEAN )
				{
					if ( banArray[1] > 0)
					{
						valid = true;
						banArray[1]--;
						if ( playerId == 0 )
						{
							gs.lampBanned--;
						}
					} 
					
						
				}
			}
			
			if ( theBanCard.instrument1 == BanCard.INSTRUMENT_HELMET || theBanCard.instrument2 == BanCard.INSTRUMENT_HELMET )
			{
				if ( theBanCard.function == ToolCard.FUNCTION_FORBIT)
				{
					valid = true;
					banArray[2]++;
					if ( playerId == 0 )
					{
						gs.helmetBanned++;
					}
				}
				else if ( theBanCard.function == ToolCard.FUNCTION_CLEAN )
				{
					if ( banArray[2] > 0)
					{
						valid = true;
						banArray[2]--;
						if ( playerId == 0 )
						{
							gs.helmetBanned--;
						}
					}
						
				}
			}
			if ( valid  )
			{
			
			
			String message;
			if ( theBanCard.instrument2 == BanCard.INSTRUMENT_NULL  )
			{
				message= gs.name + BanCard.getFunctionName(theBanCard.function) + gs.playerNameMap.get(playerId).name + " on " +BanCard.getInstrumentName(theBanCard.instrument1) ;
			}
			else
			{
				message= gs.name + BanCard.getFunctionName(theBanCard.function) + gs.playerNameMap.get(playerId).name + " on " +BanCard.getInstrumentName(theBanCard.instrument1) +", " + BanCard.getInstrumentName(theBanCard.instrument2) ;
			}
			//gs.gf.gameInfoPanel.banStatus.setText("BAN:AXE("+banArray[0]+"),LAMP("+banArray[1]+"),HELMET("+banArray[2]+")");
			//UpdateTableInfo.update(gf, gs.playerNameMap.get(playerId).name, banArray[0], banArray[1],banArray[2] );
			UpdateBanTable.update(gf, playerId, banArray[0], banArray[1], banArray[2]);
			UpdateGameLog.update( gs.gf, message);
			gs.sendToAllClient ( new UpdateBanTableMessage ( playerId, banArray[0], banArray[1], banArray[2]));
			gs.sendToAllClient( new BanNotificationMessage ( message, banArray[0],banArray[1],banArray[2],playerId , 0, gs.playerNameMap.get(playerId).name));
			gs.finishAction(gs.findCardUsedPos());
			}
			
		}
		else
		{
			Client client = (Client) gf.entity;
			System.err.println("PlayerButtonListener: original.function, original.seatLocation" + theBanCard.function + "," + this.seatLocation);
			BanRequestMessage bqm = new BanRequestMessage( theBanCard.function,seatLocation , theBanCard.instrument1, theBanCard.instrument2) ;
			System.err.println("PlayerButtonListener: bqm.function, bqm.seatLocation" + bqm.function + "," + bqm.seatLocation);
			client.sentToHost( bqm );
			client.getResponseFromHost();

		}




	}
	
	}
	
}




