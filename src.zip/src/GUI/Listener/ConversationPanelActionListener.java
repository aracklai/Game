package GUI.Listener;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import GUI.GameFrame;
import Networking.Client;
import Networking.Host;
import Networking.Message.ConversationMessage;

public class ConversationPanelActionListener implements ActionListener {
	
	private GameFrame					parent;
	private StyledDocument				doc;
	
	public ConversationPanelActionListener(GameFrame gf, StyledDocument doc){
		parent = gf;
		this.doc = doc;
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		String message = parent.conversationPanel.enterTextField.getText();
	    
		if(message.length() > 0){
			insert(message, parent.entity.color);
			parent.conversationPanel.enterTextField.setText("");
			parent.conversationPanel.textLogArea.setCaretPosition(parent.conversationPanel.textLogArea.getDocument().getLength()); 
		}
		
		if(parent.entity instanceof Host){
			Host host = (Host) parent.entity;
			host.sendToAllClient(new ConversationMessage(parent.entity.name+": "+message+ "\n" , host.color));
		}else{
			Client client = (Client) parent.entity;
			client.sentToHost(new ConversationMessage(parent.entity.name+": "+message+ "\n",client.color));
		}
	}

	private void insert(String message, Color color) {
		try {
			Style style = doc.addStyle("Style", null);
			if ( color == null)
				System.out.println( " color is null");
		    StyleConstants.setForeground(style, color);
		    
			doc.insertString(doc.getLength(), parent.entity.name+": "+message + "\n", style);
			System.out.println( "Conversation panel listener: enter a message");
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
	}


}
