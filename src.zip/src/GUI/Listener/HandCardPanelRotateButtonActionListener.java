package GUI.Listener;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

import GUI.GameFrame;

import GameEngine.RoadCard;
import Resource.ImageValue;


public class HandCardPanelRotateButtonActionListener implements ActionListener{

	
	public GameFrame gf;
	ImageValue iv;
	
	public HandCardPanelRotateButtonActionListener( GameFrame gf) 
	{
		this.gf = gf;
		
		this.iv = new ImageValue();
	}
	
	
	public int rotate(int i){
		
		if(i < 100)
			return i * 100;
		else 
			return i / 100;
	}
	
	private RoadCard change_card_attribute(RoadCard rc) {
		
		boolean temp;
		
		RoadCard newRc = new RoadCard( rc );
		
		if(rc.toDown != rc.toUp){
			//temp = rc.toDown;
			newRc.toDown = rc.toUp;
			newRc.toUp = rc.toDown;
		}
		
		if(rc.toLeft != rc.toRight){
			//temp = rc.toLeft;
			newRc.toLeft = rc.toRight;
			newRc.toRight = rc.toLeft;
		}
		
		newRc.id = rotate(rc.id);
			
		
		return newRc;	
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if(gf.handCardPanel.A == true && gf.entity.handCards[0] instanceof RoadCard)
		{
			RoadCard rc = (RoadCard) gf.entity.handCards[0];
			
			if(rc.canRotate)
			{

				//int origional_card_id = rc.id;
				//int new_card_id;
				
				//new_card_id = rotate(origional_card_id);
				//rc.id = new_card_id;
				
				
				
				gf.entity.handCards[0] = change_card_attribute(rc);
				
				Image img = iv.getImage(gf.entity.handCards[0].id,ImageValue.HAND_CARD_DIMENSION);
				gf.handCardPanel.handCardButton1.setIcon(new ImageIcon(img));
			}
			RoadCard temp = (RoadCard) gf.entity.handCards[0];
			System.out.println("Pressed rotate button:"+"ToUp:"+temp.toUp+",ToDown:"+ temp.toDown+",ToLeft:"+temp.toLeft+",toRight:"+temp.toRight);
					

		}
		
		else if(gf.handCardPanel.B == true && gf.entity.handCards[1] instanceof RoadCard)
		{
			RoadCard rc = (RoadCard) gf.entity.handCards[1];
			
			if(rc.canRotate){

				gf.entity.handCards[1] = change_card_attribute(rc);
				
				Image img = iv.getImage(gf.entity.handCards[1].id,ImageValue.HAND_CARD_DIMENSION);
				gf.handCardPanel.handCardButton2.setIcon(new ImageIcon(img));
			}
			RoadCard temp = (RoadCard) gf.entity.handCards[1];
			System.out.println("Pressed rotate button:"+"ToUp:"+temp.toUp+",ToDown:"+ temp.toDown+",ToLeft:"+temp.toLeft+",toRight:"+temp.toRight);

		}
		
		else if(gf.handCardPanel.C == true && gf.entity.handCards[2] instanceof RoadCard)
		{
			RoadCard rc = (RoadCard) gf.entity.handCards[2];
			
			if(rc.canRotate){

				gf.entity.handCards[2] = change_card_attribute(rc);
				
				Image img = iv.getImage(gf.entity.handCards[2].id,ImageValue.HAND_CARD_DIMENSION);
				gf.handCardPanel.handCardButton3.setIcon(new ImageIcon(img));

			}
			RoadCard temp = (RoadCard) gf.entity.handCards[2];
			System.out.println("Pressed rotate button:"+"ToUp:"+temp.toUp+",ToDown:"+ temp.toDown+",ToLeft:"+temp.toLeft+",toRight:"+temp.toRight);
		}
		
		else if(gf.handCardPanel.D == true && gf.entity.handCards[3] instanceof RoadCard)
		{
			RoadCard rc = (RoadCard) gf.entity.handCards[3];
			
			if(rc.canRotate){

				gf.entity.handCards[3] = change_card_attribute(rc);
				
				Image img = iv.getImage(gf.entity.handCards[3].id,ImageValue.HAND_CARD_DIMENSION);
				gf.handCardPanel.handCardButton4.setIcon(new ImageIcon(img));

			}
			RoadCard temp = (RoadCard) gf.entity.handCards[3];
			System.out.println("Pressed rotate button:"+"ToUp:"+temp.toUp+",ToDown:"+ temp.toDown+",ToLeft:"+temp.toLeft+",toRight:"+temp.toRight);
		}
		
	}

}