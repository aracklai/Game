package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import GUI.MyTableModel;
import GUI.PlayerBanStatus;
import GameEngine.UpdateGameGUI.AddBanTable;
import Networking.Entity;
import Networking.Host;
import Networking.PlayerInfo;
import Networking.Message.AddBanTableMessage;
import Resource.StringValue;

public class StartMenuItemActionListener implements ActionListener {

	
	
	Entity entity;
	public StartMenuItemActionListener ( Entity entity )
	{
		this.entity = entity;
	}
	public void actionPerformed(ActionEvent arg0) {
		
		System.out.println("pressed start menu Item");
		
		try
		{
			//host.gf.mapPanel.buttons[0][0].setImage(null);
			//host.sendToAllClient ( new GoldAndStonePositionMessage());
			
		Host gs = (Host) entity;
		if ( gs.playerNameMap.size() < 3)
		{
			JOptionPane.showMessageDialog(null, StringValue.AT_LEAST_THREE_PEOPLE , "Notification" , JOptionPane.INFORMATION_MESSAGE);
			return;
		}
	//<PlayerBanStatus> playerBanStatues = new ArrayList<PlayerBanStatus>();
		//Iterator<Entry<Integer, PlayerInfo>> entries = gs.playerNameMap.entrySet().iterator();
		ArrayList<PlayerInfo> playeInfos = new ArrayList<PlayerInfo>();
		for ( int i = 0; i < 10 ; i++)
		{
			
			//System.err.println("Start Menu Item: player Id : " + gs.seatOccupied[i]);
			//System.err.println("Start Menu Item: player name : " + gs.playerNameMap.get(gs.seatOccupied[i]).name);
			
			int playerId = gs.seatOccupied[i];
			if ( playerId != -1)
			{
				String playerName = gs.playerNameMap.get(playerId).name;
			
				playeInfos.add(new PlayerInfo ( playerId, playerName, i));
			//gs.gf.gameChairPanel.mtm.addRow(new PlayerBanStatus( playerName));
			}
		
		}
		AddBanTable.add(gs.gf, playeInfos);
		gs.sendToAllClient( new AddBanTableMessage(playeInfos));
		//System.err.println("Press start button, table is added");
	//	gs.gf.gameChairPanel.add( new JScrollPane(new JTable ( new MyTableModel(playerBanStatues) )));
		//gs.gf.gameChairPanel.repaint();
		//gs.gf.gameChairPanel.add(gs.gf.gameChairPanel.jp);
		//gs.gf.gameChairPanel.repaint();
		//gs.gf.gameChairPanel.mtm.addRow();
		if ( gs.online )
			gs.gameStart();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}

}
