package GUI.Listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import GUI.HostLoginFrame;
import GUI.InitFrame;

public class HostLoginFrameBackButtonActionListener implements ActionListener{
	
	private HostLoginFrame parent;
	public HostLoginFrameBackButtonActionListener(HostLoginFrame hostLoginFrame){
		parent = hostLoginFrame;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.print("You clicked Back!\n");
		parent.hostLoginFrame.dispose();
		new InitFrame().run();
		
	}
}
