package Main;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GamePanel extends JPanel{
	
	private static final long serialVersionUID = 5668546656808952892L;
	
	//dimensions
	public static final int WIDTH = 320;
	public static final int HEIGHT = 240;
	public static final int SCALE = 2;
	public JButton j1 = new JButton("abc");;
	public JLabel J2 = new JLabel("r12");
	
	//image 
	private BufferedImage image;
	private Graphics2D g;
	
	public GamePanel(){
		super();
		//setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
		try{
			Icon icon = new ImageIcon(getClass().getResource("/Background/0001.gif"));
			JLabel jl = new JLabel ( icon);
			add(jl);
			add(j1);
			//image = ImageIO.read(getClass().getResource("/Background/0001.gif"));

		}catch(Exception e){
			e.printStackTrace();
			System.out.print("456");
		}
		//setLayout(null);
		//setPreferredSize(new Dimension(WIDTH * SCALE, HEIGHT * SCALE));
		//add(J2);
		//add(j1);
		//j1.setBorder(null);
		//J2.setBounds(0,0,20,20);
		//j1.setBounds(50,50,80,40);
	}
	
	  public void paint(Graphics g) {
		  /*
		
		try{
			Icon icon = new ImageIcon(getClass().getResource("/Background/0001.gif"));
			JLabel jl = new JLabel ( icon);
			this.add(jl);
			//image = ImageIO.read(getClass().getResource("/Background/0001.gif"));

		}catch(Exception e){
			e.printStackTrace();
			System.out.print("456");
		}

	   // super.paintComponent(g);
		
				//g.drawImage(image, 0,0, WIDTH, HEIGHT, null);
*/
	}
	

}
