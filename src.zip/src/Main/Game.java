package Main;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Game {
	
	public static void main(String[] args){
		new Game().go();
		

	
	}
	public void go()
	{
		JFrame window = new JFrame("Tut");
		JPanel temp = new JPanel ();
		Icon icon = new ImageIcon(getClass().getResource("/Background/0001.gif"));
		JLabel jl = new JLabel ( icon);
		temp.add(jl);
		window.getContentPane().add(temp);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.pack();
		window.setVisible(true);
	}
}
