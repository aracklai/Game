package Main;

public class Console {

	public static void main(String[] args) {
		//System
		new GUI.InitFrame().run();
	}

}
