package Resource;

public class StringValue {
	
	public final static String VERSION = "BETA_1.6";
	//public final static String VERSION_OKAY = "Version okay";
	public final static String VERSION_WRONG_NOTIFICATION = "Your version is not the updatest. Please open ";
	public final static String CANNOT_FIND_THE_HOST = "Cannot find the host! Please check the IP and Port.";
	// initFramePanel:
	public final static String HOST_BUTTON = "Host";
	public final static String JOIN_BUTTON = "Join";
	public final static String EXIT_BUTTON = "Exit";
	
	// initFrame:
	public final static String WINDOW_NAME = "Dig Gold Beta "+VERSION;
	
	// HostLoginFrame:
	public final static String GOOD_GUY_NUM_LABEL = "Number of good guys:";
	public final static String BAD_GUY_NUM_LABEL = "Number of bad guys:";
	public final static String HOST_LOGIN_FRAME = "Host Login";
	
	// GuestLoginFrame:
	public final static String YOUR_NAME_LABEL = "Your name:";
	public final static String IP_LABEL = "IP:";
	public final static String PORT_LABEL = "Port:";
	public final static String START_GAME_BUTTON = "Start game!";
	public final static String BACK_BUTTON = "Back!";
	public final static String GUEST_LOGIN_FRAME = "Guest Login";
	
	// gameFrame:
	public final static String GAME_FRAME_NAME = "Game Start!";
	
	// HandCardPanel:
	public final static String HAND_CARD_BUTTON1 = "Card 1";
	public final static String HAND_CARD_BUTTON2 = "Card 2";
	public final static String HAND_CARD_BUTTON3 = "Card 3";
	public final static String HAND_CARD_BUTTON4 = "Card 4";
	public final static String ROTATE_BUTTON = "Rotate";
	public final static String DISCARD_BUTTON = "Discard";
	
	// public final static String = "";
	
	// GameLogMessage;
	public final static String PLAYER_JOIN_ROOM = " joined the room!";
	public final static String PLAYER_LEAVE_ROOM = " left the room!";
	public final static String HOST_LEAVE_ROOM = "The host left. Bye~";
	public final static String PLAYER_DESTROY_ROAD = " destroyed a road!";
	public final static String PLAYER_USE_MAP = " used a map on ";
	public final static String PLAYER_DISCARD = " discarded a card.";
	public final static String PLAYER_BUILD_ROAD = " built a road.";
	
	public final static String BAN = " banned ";
	public final static String SOLVE = " solved ";
	public final static String HELMET = "helmet";
	public final static String LAMP = "lamp";
	public final static String PICKAXE = "pickaxe";
	
	public final static String SURRENDER_MESSAGE = " surrendered, number of people surrendered: ";
	
	public final static String All_CARD_USED_MESSAGE = "****************************************************\nAll cards used, bad guys win!\n*****************************************************";
	public final static String BAD_GUY_WON_MESSAGE = "****************************************************\nMore than half good guys surrendered, bad guys win!\n*****************************************************";
	public final static String GOOD_GUY_WON_MESSAGE = "****************************************************\nGood guys dig a gold, good guys win!\n****************************************************";
	
	
	public final static String TIME_OUT_MESSAGE = " time out! Auto discard a card.";
	public final static String AT_LEAST_THREE_PEOPLE = "The game requires at least 3 people to start!";
	public final static String RESTART_MESSSAGE = "The game is refreshed, please press start again.";
}
