package Resource;

import java.awt.Color;

public class ColorValue {

	public static Color PINK = new Color (255,51,153);
	public static Color SADDLE_BROWN = new Color (139,69,19);
	public static Color RED = new Color (255,0,0);
	public static Color GOLD = new Color (218,165,32);
	public static Color OLIVE = new Color (128,128,0);
	public static Color GREEN = new Color (0,128,0);
	public static Color DARK_CYAN = new Color (0,139,139);
	public static Color DODGER_BLUE = new Color (30,144,255);
	public static Color BLUE = new Color (0,0,225);
	public static Color DARK_VIOLET = new Color (148,0,211); 
}
