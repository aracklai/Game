package Resource;

import java.awt.Image;

import javax.imageio.ImageIO;

public class ImageValue {
	
	
	public static int TYPE_ROAD = 0;
	public static int TYPE_TOOL = 1;
	public static int TYPE_CHARACTER = 2;
	public static int MAP_CARD_DIMENSION = 6;
	public static int HAND_CARD_DIMENSION = 4;
	public static int TABLE_DIMENSION = 5;
	public static int IDENTITY_CARD_DIMENSION = 3;
	public ImageValue ( )
	{
		
	}
	
	public Image getImage ( int id , int dimenion )
	{
		try
		{
				Image img;
				img = ImageIO.read(getClass().getResource("/cards/roads/"+id+".png"));
				
				if ( dimenion ==  ImageValue.IDENTITY_CARD_DIMENSION)
				{
					return img.getScaledInstance( 160/dimenion, 160/dimenion,  java.awt.Image.SCALE_SMOOTH ) ;
				}
				else if ( dimenion == ImageValue.TABLE_DIMENSION )
				{
					return img.getScaledInstance(160,75,java.awt.Image.SCALE_SMOOTH);
				}
				else if ( dimenion == ImageValue.HAND_CARD_DIMENSION )
				{
					return img.getScaledInstance( 90, 60,  java.awt.Image.SCALE_SMOOTH ) ;
				}
	
				else 
					return img.getScaledInstance( 300/dimenion, 200/dimenion,  java.awt.Image.SCALE_SMOOTH ) ;
			
			
			
			
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		return null;
	}
	

}
