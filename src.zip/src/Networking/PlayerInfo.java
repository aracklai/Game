package Networking;

import java.io.ObjectOutputStream;
import java.io.Serializable;

public class PlayerInfo implements Serializable {
	
	
	public int id;
	public String name;
	public int seatLocation;
	//public ObjectOutputStream oos;
	
	public PlayerInfo (  int id ,String name , int seatLocation)//, ObjectOutputStream oos )
	{
		this.id = id;
		this.name = name;
		this.seatLocation = seatLocation;
		//this.oos = oos;
	}

}
