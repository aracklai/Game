package Networking;

import java.awt.Color;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import GUI.GameFrame;
import GameEngine.Card;
import Networking.Message.FinishActionMessage;

public abstract class Entity {
	
	public int seatLocation;
	public int numberOfHandCard;
	public Card[] handCards;
	public GameFrame gf;
	public Color color;
	public int port;
	public int id;
	public String name;
	private boolean yourTurn;
	public boolean goodGuy;
	public boolean surrendered;
	public int helmetBanned;
	public int lampBanned;
	public int pickaxeBanned;
	
	public Timer timer = new Timer();
	// int interval = 20;
	public int delay = 0;
	public int period = 1000;
	public Object actionLock;
	public boolean sendOutARequest;
	
	
	public Entity ( GameFrame gf, int port , String name  )
	{
		this.goodGuy = false;
		this.gf = gf;
		this.port = port;
		this.name = name;
		this.yourTurn = false;
		this.helmetBanned = 0;
		this.lampBanned = 0;
		this.pickaxeBanned = 0;
		this.surrendered = false;
		this.actionLock = new Object();
	}
	public void refresh()
	{
		gf.gameInfoPanel.refresh();
		gf.mapPanel.refresh();
		gf.handCardPanel.refresh();
		gf.gameChairPanel.refresh();
		
		this.surrendered = false;
		this.yourTurn = false;
		this.goodGuy = false;
		this.helmetBanned = 0;
		this.lampBanned = 0;
		this.pickaxeBanned = 0;
		this.numberOfHandCard = 0;
		for ( int i = 0; i < 4 ; i++ )
			handCards[i] = null;
		
	}
	public abstract boolean finishAction( int cardUsedPos);
	public abstract void countDown();
	public int findCardUsedPos()
	{
		if ( this.gf.handCardPanel.A )
		{
			return 0;
		}
		else if ( this.gf.handCardPanel.B)
		{
			return 1;
		}
		else if ( this.gf.handCardPanel.C )
		{
			return 2;
		}
		else if ( this.gf.handCardPanel.D )
		{
			return 3;
		}
		
		return -1;
	}
	public boolean checkAllCardNull()
	{
		if ( handCards[0] == null && handCards[1] == null && handCards[2] == null && handCards[3] == null)
			return true;
		else return false;
	}
	
	public void setYourTurn ( boolean b )
	{
		this.yourTurn = b;
	}
	
	synchronized public boolean getYourTurn ()
	{
		return this.yourTurn;
	}

}
