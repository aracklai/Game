package Networking;

import java.io.ObjectInputStream;
import GameEngine.UpdateGameGUI.ShowAllIdentities;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import GUI.GameFrame;
import GameEngine.Card;
import GameEngine.RoadCard;
import GameEngine.UpdateGameGUI.AddBanTable;
import GameEngine.UpdateGameGUI.AddConversation;
import GameEngine.UpdateGameGUI.CollectHandCard;
import GameEngine.UpdateGameGUI.FaceUpGoldOrStone;
import GameEngine.UpdateGameGUI.PopUpMap;
import GameEngine.UpdateGameGUI.PutGoldAndStoneOnMap;
import GameEngine.UpdateGameGUI.PutPlayerNameOnTable;
import GameEngine.UpdateGameGUI.PutRoadCardOnMap;
import GameEngine.UpdateGameGUI.RemoveRoadCardFromMap;
import GameEngine.UpdateGameGUI.ShowIdentity;
import GameEngine.UpdateGameGUI.UpdateBanStatus;
import GameEngine.UpdateGameGUI.UpdateBanTable;
import GameEngine.UpdateGameGUI.UpdateCardLeft;
import GameEngine.UpdateGameGUI.UpdateCountDown;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import GameEngine.UpdateGameGUI.UpdateHandCard;
import GameEngine.UpdateGameGUI.UpdateTableInfo;
import GameEngine.UpdateGameGUI.UpdateWhoTurn;

import Networking.Message.AddBanTableMessage;
import Networking.Message.BanNotificationMessage;
import Networking.Message.CardLeftMessage;
import Networking.Message.ConversationMessage;
import Networking.Message.DiscardMessage;
import Networking.Message.DistributeHandCardMessage;
import Networking.Message.FaceUpGoldOrStoneOnMapMessage;
import Networking.Message.FinishActionMessage;
import Networking.Message.GameEndMessage;
import Networking.Message.IdentityMessage;
import Networking.Message.LeaveMessage;
import Networking.Message.PlayerInfoListMessage;
import Networking.Message.PlayerJoinMessage;
import Networking.Message.PutGoldAndStoneOnMapMessage;
import Networking.Message.PutRoadCardOnMapNotificationMessage;
import Networking.Message.RefreshMessage;
import Networking.Message.RemoveACardFromMapNotificationMessage;
import Networking.Message.ResponseMessage;
import Networking.Message.SurrenderNotificationMessage;
import Networking.Message.TimeOutMessage;
import Networking.Message.UpdateBanTableMessage;
import Networking.Message.UseMapNotificationMessage;
import Networking.Message.YourTurnMessage;
import Resource.ImageValue;
import Resource.StringValue;

public class Client extends Entity implements Runnable{
	
	public String ip; // server ip
	Socket s; // socket connect to server
	public ObjectInputStream ois; // input from server
	public ObjectOutputStream oos; // output to server
	ResponseMessage responseMessage;
	
	
	ImageValue iv;
	
	public Client ( GameFrame gf ,  int port, String name , String ip)
	{
		
		super ( gf , port , name);
		this.ip = ip;
		handCards = new Card[4];
		numberOfHandCard = 0;
		iv = new ImageValue();
		responseMessage = null;
	}

	@Override
	public void run() {
		try
		{
			try
			{
				s = new Socket ( ip, port );
			}
			catch ( Exception e)
			{
				JOptionPane.showMessageDialog(null, StringValue.CANNOT_FIND_THE_HOST , "Cannot find the host" , JOptionPane.ERROR_MESSAGE);
				System.exit(1);
			}
			oos = new ObjectOutputStream ( s.getOutputStream() );
			ois = new ObjectInputStream ( s.getInputStream() );
			//oos.writeObject(StringValue.VERSION);
			
			String versionChecking = (String) ois.readObject();
			if ( !versionChecking.equals(StringValue.VERSION) )
			{
				oos.writeObject(new LeaveMessage(-1,"",-1));
				JOptionPane.showMessageDialog(null, StringValue.VERSION_WRONG_NOTIFICATION + versionChecking  , "Version Checking" , JOptionPane.INFORMATION_MESSAGE);
				System.exit(1);
				return;
			}
			else
			{
				System.err.println("Client: Version same as Host");
			}
			oos.writeObject(name);
			
			
			PlayerInfoListMessage pilm = ( PlayerInfoListMessage ) ois.readObject();
			id = pilm.theID;
			seatLocation = pilm.playerNameMap.get(id).seatLocation;
			this.color = pilm.theColor;
			
			Iterator<Entry<Integer, PlayerInfo>> entries = pilm.playerNameMap.entrySet().iterator();
			//int[] playerIDs = new int[playerNameMap.size()];
			//int tmp = 0;
			//int numberOfPeopleAdded = 0;
			while ( entries.hasNext() )
			{
				Entry<Integer,PlayerInfo> thisEntry = entries.next();
				String theName = (String) thisEntry.getValue().name;
				PutPlayerNameOnTable.put(gf,thisEntry.getValue().seatLocation,theName);
				//numberOfPeopleAdded++;
				
				//playerIDs[tmp] = entries.next().getKey();
				//tmp++;
			}
			// take information from map and put it on the table
			
			while (true)
			{
				Object message;
				message = ois.readObject();
				if ( message instanceof LeaveMessage )
				{
					LeaveMessage lm = (LeaveMessage) message;
					if ( lm.id == 0 )
					{
						JOptionPane.showMessageDialog(null, StringValue.HOST_LEAVE_ROOM , "Notification" , JOptionPane.INFORMATION_MESSAGE);
						System.exit(1);
					}
					else 
					{
						UpdateGameLog.update(gf, lm.name + StringValue.PLAYER_LEAVE_ROOM);
					}
					PutPlayerNameOnTable.put(gf, lm.seatLocation, "");
					
				}
				else if ( message instanceof Card) // get a card from host when start the game
				{
					if ( numberOfHandCard < 4 )
					{
						Card c = (Card)message;
						handCards[numberOfHandCard] = c;
						CollectHandCard.collect(gf , c.id , numberOfHandCard);
						numberOfHandCard++;
					}
				}
				else if ( message instanceof PutRoadCardOnMapNotificationMessage )
				{
					PutRoadCardOnMapNotificationMessage prcomrm = (PutRoadCardOnMapNotificationMessage) message;
					UpdateGameLog.update(gf, prcomrm.logMessage);
					int row = prcomrm.row;
					int column = prcomrm.column;
					RoadCard rc = prcomrm.rc;
					prcomrm = null;
					System.out.println("Client get a put road card on map notify");
					System.out.println( "id:" + rc.id  );
					PutRoadCardOnMap.put(gf,row,column, rc);
					
					//yourTurn = false;
					
				}
				else if ( message instanceof YourTurnMessage )
				{
					System.out.println("Client receive your Turn Message");
					YourTurnMessage ytm = (YourTurnMessage) message;
					UpdateWhoTurn.update(gf, ytm.seatLocation,ytm.previousSeatLocation);
					if (ytm.id == id )
					{
						this.setYourTurn(true);
						if ( checkAllCardNull() )
						{
							this.sentToHost(new GameEndMessage(StringValue.All_CARD_USED_MESSAGE,null));
						}
						
						this.countDown();
					}
					else this.setYourTurn(false);
					
					//System.out.println("my turn:"+ yourTurn);
					
					
					
					//this.timer.cancel();
					
					
				}
				else if ( message instanceof PutGoldAndStoneOnMapMessage )
				{
					PutGoldAndStoneOnMap.put(gf);
				}
				else if ( message instanceof PlayerJoinMessage )
				{
					PlayerJoinMessage pjm = (PlayerJoinMessage) message;
					
					PutPlayerNameOnTable.put(gf,pjm.seatLocation,pjm.name);
					//playerNameMap.put(pjm.id, pjm.name);
					UpdateGameLog.update(gf, pjm.name + StringValue.PLAYER_JOIN_ROOM);
				}
				else if ( message instanceof FaceUpGoldOrStoneOnMapMessage )
				{
					FaceUpGoldOrStoneOnMapMessage fugosomm = (FaceUpGoldOrStoneOnMapMessage) message;
					FaceUpGoldOrStone.faceUp(this, fugosomm.id, fugosomm.row, fugosomm.column);
				}
				else if ( message instanceof DistributeHandCardMessage )
				{
					DistributeHandCardMessage dhcm = (DistributeHandCardMessage) message;
					if ( dhcm.card != null )
					{
						System.out.println( "client get a card: " + dhcm.card.id);
						//for ( int i  = 0 ; i < 4 ; i ++ )
					
						//{
							//if ( this.handCards[i] == null )
							//{
								System.out.println("client: update hand card after action");
								//this.handCards[i] = dhcm.card;
								UpdateHandCard.update(gf, dhcm.card , dhcm.pos);
								//break;
							//}
						//}
					}
					else
					{
						UpdateHandCard.update(gf, dhcm.card, dhcm.pos);
					}
					//if ( yourTurn )
					//	sentToHost( new FinishActionMessage());
					
				}
				else if ( message instanceof CardLeftMessage )
				{
					CardLeftMessage dm = ( CardLeftMessage)message ;
					UpdateCardLeft.put(gf, dm.num_of_card_left);
					
					
				}
				else if ( message instanceof DiscardMessage )
				{
					DiscardMessage dm = (DiscardMessage) message;
					UpdateGameLog.update(gf, dm.message);
				}
				
				else if ( message instanceof RemoveACardFromMapNotificationMessage)
				{
					RemoveACardFromMapNotificationMessage racfmm = (RemoveACardFromMapNotificationMessage) message;
					RemoveRoadCardFromMap.remove(gf, racfmm.row, racfmm.column);
			
					UpdateGameLog.update(gf,racfmm.message);
				}
				else if (message instanceof ConversationMessage)
				{
					ConversationMessage cm = (ConversationMessage) message;
					AddConversation.add(gf, ((ConversationMessage) message).getConversation(), cm.color);
				}
				else if ( message instanceof IdentityMessage )
				{
					IdentityMessage im = (IdentityMessage) message;
					if ( im.identity == IdentityMessage.GOOD_GUY)
					{
						this.goodGuy = true;
					}
					ShowIdentity.show(gf, im.identity);
				}
				else if ( message instanceof UseMapNotificationMessage)
				{
					UseMapNotificationMessage aumm = (UseMapNotificationMessage) message;
					
					UpdateGameLog.update(gf, aumm.message);
				
				
				}
				else if ( message instanceof RefreshMessage )
				{
					this.refresh();
				}
				else if (message instanceof BanNotificationMessage)
				{
					BanNotificationMessage bnm = (BanNotificationMessage) message;
					UpdateGameLog.update(gf, bnm.message);
					UpdateTableInfo.update(gf, bnm.beBannerName, bnm.axe, bnm.lamp, bnm.helmet);
					if ( bnm.beBannerId == this.id )
					{
						this.pickaxeBanned = bnm.axe;
						this.lampBanned = bnm.lamp;
						this.helmetBanned = bnm.helmet;

						UpdateBanStatus.update(gf,"BAN:AXE("+gf.entity.pickaxeBanned+"),LAMP("+gf.entity.lampBanned+"),HELMET("+gf.entity.helmetBanned+")");
					}
					if ( bnm.requesterId == this.id)
					{
						this.finishAction(findCardUsedPos());
					}
				}
				else if ( message instanceof AddBanTableMessage )
				{
					AddBanTableMessage abtm = (AddBanTableMessage) message;
					AddBanTable.add(gf, abtm.playerInfos);
				}
				else if ( message instanceof UpdateBanTableMessage )
				{
					UpdateBanTableMessage ubtm = (UpdateBanTableMessage) message;
					UpdateBanTable.update(gf, ubtm.id, ubtm.axe, ubtm.lamp, ubtm.helmet);
				}
				else if ( message instanceof SurrenderNotificationMessage )
				{
					SurrenderNotificationMessage snm = (SurrenderNotificationMessage) message;
					
					UpdateGameLog.update(gf, snm.message);
				}
				else if ( message instanceof GameEndMessage )
				{
					this.setYourTurn(false);
					this.timer.cancel();
					GameEndMessage gem = (GameEndMessage) message;
					
					UpdateGameLog.update(gf, gem.message);
					ShowAllIdentities.show(gf, gem.aim);
				}
				else if ( message instanceof TimeOutMessage )
				{
					TimeOutMessage tom = (TimeOutMessage) message;
					UpdateGameLog.update(gf, tom.logMessage);
				}
				else if ( message instanceof ResponseMessage )
				{
					ResponseMessage rm = (ResponseMessage) message;
					this.responseMessage = rm;
					System.err.println("client: get a ResponseMessage");
				}
				
				//else if ( message instanceof PlayerInfoListMessage )
				//{
				//	PlayerInfoListMessage pilm  = (PlayerInfoListMessage) message;
				//}
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		
	}
	public void sentToHost( Object o)
	{
 		try
		{
			oos.writeObject(o);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	public void countDown()
	{
		
		if ( this.getYourTurn() )
		{
		
		timer = new Timer();
		
		timer.scheduleAtFixedRate(new TimerTask()
		{
			int interval = 20;
	        public void run() 
	        {
	        	
	        	//System.err.println("Interval : "+interval);
	        	if ( getYourTurn() )
	        		UpdateCountDown.update(gf,interval);
	          
	        	if ( interval <= 0) 
	        	{
	        	  //interval = 20;
	        		synchronized(gf.entity.actionLock)
	        		{
	        			System.err.println("timer acquire the action lock ");
	        		
	        			if ( getYourTurn() )
	        			{
	        		  // auto discard
	        				int discardPos = -1;
	        				for ( int i = 0 ; i < 4 ; i++)
	        				{
	        					if ( handCards[i] != null)
	        					{
	        						UpdateHandCard.update(gf,null, i);
	        						discardPos = i;
	        						break;
	        					}
	        			  
	        				}
	        		  
	        		  
	        				if ( finishAction(discardPos) )
	        				{
	        					String logMessage = name + StringValue.TIME_OUT_MESSAGE;
	        		  
	        		  
	        					sentToHost(new TimeOutMessage(logMessage ));
	        				}
	        		
	        			}
	        		
	        		}
	        	  
	        	  
	        		
	          }
	         
	          
	          interval--;
	        }
	    }, delay, period);
		
		}
	}

	@Override
	synchronized public boolean finishAction( int cardUsedPos)
	{
		
		if ( !getYourTurn() )
		{
			return false;
		}
		this.setYourTurn(false);
		UpdateCountDown.update(gf,-1);
		timer.cancel();
		this.sentToHost( new FinishActionMessage(cardUsedPos) );
		return true;
	
		
		
	}
	synchronized public void getResponseFromHost()
	{
		
		while ( true )
		{
			if ( this.responseMessage != null )
			{
				System.out.println("client : " + this.id + " , got a response message");
				
				if ( this.responseMessage.message.equals(ResponseMessage.YES) )
				{
					System.out.println("client : " + this.id + " , got a response message,YES");
					this.finishAction(this.findCardUsedPos());
					if ( this.responseMessage.mapId != 0 )
					{
						System.out.println("client : " + this.id + " , got a watch map id ," + this.responseMessage.mapId);
						PopUpMap.popUp(this.responseMessage.mapId);
					}
					else
					{
						System.out.println("client : " + this.id + " , got a invalid watch map id ," + this.responseMessage.mapId);
					}
				}
				else
				{
					System.out.println("client : " + this.id + " , got a response message,NO");
				}
				this.responseMessage = null;
				break;
			}
		}
	
	}
	

}
