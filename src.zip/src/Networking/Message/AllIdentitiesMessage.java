package Networking.Message;

import java.io.Serializable;
import java.util.HashMap;

public class AllIdentitiesMessage implements Serializable {

	public HashMap<Integer,Integer> identitiesMap;
	public AllIdentitiesMessage( HashMap<Integer,Integer> identitiesMap )
	{
		this.identitiesMap = identitiesMap;
	}
}
