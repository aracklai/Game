package Networking.Message;

import java.io.Serializable;

public class UpdateBanTableMessage implements Serializable {
	
	public int id;
	public int axe;
	public int lamp;
	public int helmet;
	public UpdateBanTableMessage ( int id , int axe , int lamp , int helmet )
	{
		this.id = id;
		this.axe = axe;
		this.lamp = lamp;
		this.helmet = helmet;
	}
}
