package Networking.Message;

import java.io.Serializable;

public class PutGoldAndStoneOnMapMessage implements Serializable {

}
