package Networking.Message;

import java.awt.Color;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

import Networking.PlayerInfo;

public class PlayerInfoListMessage implements Serializable {
	

	public HashMap<Integer, PlayerInfo> playerNameMap;
	public int theID;
	public Color theColor;
	public PlayerInfoListMessage ( HashMap<Integer, PlayerInfo> playerNameMap , int theID , Color theColor)
	{
		this.playerNameMap = playerNameMap;
		this.theID = theID;
		this.theColor = theColor;
		
	}

}
