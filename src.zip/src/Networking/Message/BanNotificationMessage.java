package Networking.Message;

import java.io.Serializable;

public class BanNotificationMessage implements Serializable {

	public String message;
	public int axe;
	public int lamp;
	public int helmet;
	public int beBannerId;
	public int requesterId;
	public String beBannerName;


	public BanNotificationMessage ( String message, int axe, int lamp, int helmet, int beBannerId , int requesterId, String beBannerName)
	{
		this.message = message;
		this.axe = axe;
		this.lamp = lamp;
		this.helmet = helmet;
		this.beBannerId = beBannerId;
		this.requesterId = requesterId;
		this.beBannerName = beBannerName;
	}


}