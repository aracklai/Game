package Networking.Message;

import java.io.Serializable;

public class IdentityMessage implements Serializable {

	public static final int GOOD_GUY = 0;
	public static final int BAD_GUY = -1;
	public int identity;
	
	public IdentityMessage ( int identity)
	{
		this.identity = identity;
	}
}
