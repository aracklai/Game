package Networking.Message;

public class BuildRoadMessage {

}
