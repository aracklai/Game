package Networking.Message;

import java.io.Serializable;
import Resource.StringValue;

public class RemoveACardFromMapNotificationMessage implements Serializable {
	
	public int row;
	public int column;
	public String message;
	public RemoveACardFromMapNotificationMessage ( int row , int column, String message )
	{
		this.row = row;
		this.column = column;
		this.message = message;
	}

}
