package Networking.Message;

import java.awt.Color;
import java.io.Serializable;

public class ConversationMessage implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5297153514547459582L;
	private String conversation;
	public Color color;
	public ConversationMessage ( String conversation , Color color  )
	{
		this.conversation = conversation;
		this.color = color;
	}
	
	public String getConversation()
	{
		return conversation;
	}

}
