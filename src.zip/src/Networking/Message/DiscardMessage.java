package Networking.Message;

import java.io.Serializable;
import Resource.StringValue;

public class DiscardMessage implements Serializable{
	
	public String message;
	public DiscardMessage ( String name )
	{
		this.message = name + StringValue.PLAYER_DISCARD;
	}

}
