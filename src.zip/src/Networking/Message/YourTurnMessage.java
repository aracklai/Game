package Networking.Message;

import java.io.Serializable;

public class YourTurnMessage implements Serializable{
	
	public int id;
	public int seatLocation;
	public int previousSeatLocation;
	public YourTurnMessage( int id, int seatLocation , int previousSeatLocation )
	{
		this.id = id;
		this.seatLocation = seatLocation;
		this.previousSeatLocation = previousSeatLocation;
	}

}
