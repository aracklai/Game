package Networking.Message;

import java.io.Serializable;

public class BanRequestMessage implements Serializable{
	
	public int function;
	public int seatLocation;
	
	public int instrument1;
	public int instrument2;
	
	public BanRequestMessage ( int function, int seatLocation, int instrument1, int instrument2) 
	{
		
		this.function = function;
		this.seatLocation = seatLocation;
		this.instrument1 = instrument1;
		this.instrument2 = instrument2;
	}

}
