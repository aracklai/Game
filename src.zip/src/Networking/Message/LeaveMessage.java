package Networking.Message;

import java.io.Serializable;

public class LeaveMessage implements Serializable {
	
	public int id;
	public String name;
	public int seatLocation;
	public LeaveMessage ( int id , String name , int seatLocation)
	{
		this.id = id;
		this.name = name;
		this.seatLocation = seatLocation;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 2412708200698144693L;

}
