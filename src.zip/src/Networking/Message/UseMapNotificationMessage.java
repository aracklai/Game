package Networking.Message;

import java.io.Serializable;

import Resource.StringValue;

public class UseMapNotificationMessage implements Serializable {

	public String message;

	
	public UseMapNotificationMessage ( int column, String userName )
	{
		
		
		if ( column == 0 )
			this.message = userName + StringValue.PLAYER_USE_MAP + "left";
		else if ( column == 2 )
			this.message = userName + StringValue.PLAYER_USE_MAP + "middle";
		else if ( column == 4 )
			this.message = userName + StringValue.PLAYER_USE_MAP + "Right";
	}

}
