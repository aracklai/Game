package Networking.Message;

import java.io.Serializable;

public class UseMapRequestMessage implements Serializable{
	
	
	public int row;
	public int column;
	
	public String name;
	public UseMapRequestMessage  ( int row , int column , String name )
	{
		this.row = row;
		this.column = column;
		
		this.name = name;
	}

}
