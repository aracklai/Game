package Networking.Message;

import java.io.Serializable;

public class DrawANewCardRequestMessage implements Serializable{

}
