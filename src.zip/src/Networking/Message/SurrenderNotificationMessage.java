package Networking.Message;

import java.io.Serializable;

public class SurrenderNotificationMessage implements Serializable{
	public String message;
	
	public SurrenderNotificationMessage ( String message )
	{
		this.message = message;
	}

}
