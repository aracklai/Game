package Networking.Message;

import java.io.Serializable;

public class GameRuleMessage implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3532593897458004893L;
	public int numberOfPlayer;
	public int numberOfGoodGuy;
	public int numberOfBadGuy;
	
	public GameRuleMessage ( int numberOfPlayer, int numberOfGoodGuy, int numberOfBadGuy )
	{
		this.numberOfPlayer = numberOfPlayer;
		this.numberOfGoodGuy = numberOfGoodGuy;
		this.numberOfBadGuy = numberOfBadGuy;
	}

}
