package Networking.Message;

import java.io.Serializable;

import GameEngine.RoadCard;

public class PutRoadCardOnMapRequestMessage implements Serializable {
	
	public int row;
	public int column;
	public RoadCard rc;
	public String logMessage;
	public PutRoadCardOnMapRequestMessage( int row, int column, RoadCard rc ,String message )
	{
		this.row = row;
		this.column = column;
		this.rc = rc;
		this.logMessage = message;
		
	}

}
