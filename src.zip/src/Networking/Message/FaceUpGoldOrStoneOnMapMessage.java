package Networking.Message;

import java.io.Serializable;

import GameEngine.RoadCard;

public class FaceUpGoldOrStoneOnMapMessage implements Serializable {
	
	public int row;
	public int column;
	public int id;
	public FaceUpGoldOrStoneOnMapMessage ( int row ,int column , int id)
	{
		this.row = row;
		this.column = column;
		this.id = id;
	}

}
