package Networking.Message;

import java.io.Serializable;

public class ResponseMessage implements Serializable {

	public static final String YES = "YES";
	public static final String NO = "NO";
	
	public String message;
	public int mapId;
	
	public ResponseMessage ( String message, int mapId )
	{
		this.message = message;
		this.mapId = mapId;
	}

}
