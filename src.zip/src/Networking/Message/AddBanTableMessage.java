package Networking.Message;

import java.io.Serializable;
import java.util.ArrayList;

import Networking.PlayerInfo;

public class AddBanTableMessage implements Serializable {
	
	public ArrayList<PlayerInfo> playerInfos;
	public AddBanTableMessage ( ArrayList<PlayerInfo> playerInfos )
	{
		this.playerInfos = playerInfos;
	}

}
