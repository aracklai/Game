package Networking.Message;

import java.io.Serializable;


public class FinishActionMessage implements Serializable {

	public int cardUsedPos;
	public FinishActionMessage ( int cardUsedPos )
	{
		this.cardUsedPos = cardUsedPos;
	}
}
