package Networking.Message;

import java.io.Serializable;

public class CardLeftMessage implements Serializable {

	public int num_of_card_left;
	
	public CardLeftMessage(int num_of_card_left) {
		this.num_of_card_left = num_of_card_left;
	}

}
