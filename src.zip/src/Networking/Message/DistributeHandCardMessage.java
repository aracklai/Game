package Networking.Message;

import java.io.Serializable;

import GameEngine.Card;



public class DistributeHandCardMessage implements Serializable {
	
	public Card card;
	public int pos;
	public DistributeHandCardMessage (  Card card , int pos)
	{
		this.card = card;
		this.pos = pos;
	}
}
