package Networking.Message;

import java.io.Serializable;

public class TimeOutMessage implements Serializable {
	
	public String logMessage;
	
	public TimeOutMessage ( String logMessage )
	{
		this.logMessage = logMessage;
	}

}
