package Networking.Message;

public class ForbitMessage {

}
