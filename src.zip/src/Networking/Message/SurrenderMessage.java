package Networking.Message;

import java.io.Serializable;

public class SurrenderMessage implements Serializable {
	
	
	

}
