package Networking.Message;

public class CleanMessage {

}
