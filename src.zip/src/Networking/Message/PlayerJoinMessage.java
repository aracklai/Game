package Networking.Message;

import java.io.Serializable;

public class PlayerJoinMessage implements Serializable {
	
	public int id;
	public String name;
	public int seatLocation;
	public PlayerJoinMessage ( int id , String name, int seatLocation )
	{
		this.id = id;
		this.name = name;
		this.seatLocation = seatLocation;
	}

}
