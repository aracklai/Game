package Networking.Message;

import java.io.Serializable;

public class GameEndMessage implements Serializable {
	public String message;
	public AllIdentitiesMessage aim;
	public GameEndMessage ( String message , AllIdentitiesMessage aim )
	{
		this.message = message;
		this.aim = aim;
	}

}
