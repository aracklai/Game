package Networking.Message;

import java.io.Serializable;

public class RefreshMessage implements Serializable {
	
	

}
