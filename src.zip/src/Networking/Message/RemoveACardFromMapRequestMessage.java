package Networking.Message;

import java.io.Serializable;

import Resource.StringValue;

public class RemoveACardFromMapRequestMessage implements Serializable {
	
	public int row;
	public int column;
	public String message;
	public RemoveACardFromMapRequestMessage ( int row , int column, String name )
	{
		this.row = row;
		this.column = column;
		this.message = name + StringValue.PLAYER_DESTROY_ROAD;
	}

}
