package Networking;

import java.awt.Color;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;

import java.util.Map.Entry;

import org.ietf.jgss.GSSContext;


import GUI.GameFrame;
import GameEngine.Card;
import GameEngine.GameEngine;
import GameEngine.UpdateGameGUI.PutPlayerNameOnTable;
import GameEngine.UpdateGameGUI.UpdateCardLeft;
import GameEngine.UpdateGameGUI.UpdateCountDown;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import GameEngine.UpdateGameGUI.UpdateHandCard;
import Networking.Message.CardLeftMessage;
import Networking.Message.DistributeHandCardMessage;
import Networking.Message.FinishActionMessage;
import Networking.Message.GameRuleMessage;
import Networking.Message.LeaveMessage;
import Networking.Message.PlayerInfoListMessage;
import Networking.Message.PlayerJoinMessage;
import Networking.Message.TimeOutMessage;
import Resource.ColorValue;
import Resource.StringValue;

public class Host extends Entity implements Runnable {
	

	
	public HashMap<Integer,PlayerInfo> playerNameMap;
	public ServerSocket ss;
	public boolean online;
	public HashMap<Integer,ObjectOutputStream> playerOosMap;
	public int idCounter;
	public GameEngine ge;
	Object testLock;
	public int[] seatOccupied;
	public Color[] colorList;
	public boolean[] colorUsed;
	
	public Host ( GameFrame gf, int port, String name )
	{
		super ( gf , port , name );
		this.playerNameMap = new HashMap<Integer,PlayerInfo>();
		this.playerOosMap = new HashMap<Integer,ObjectOutputStream>();
		this.idCounter = 1;
		this.online = true;
		this.handCards = new Card[4];
		this.numberOfHandCard = 0;
		this.id = 0;
		this.playerNameMap.put(id,new PlayerInfo( 0,name,0)); // put itself into list
		this.testLock = new Object();
		this.seatLocation = 0;
		seatOccupied = new int[10];
		for ( int i = 0; i < 10 ; i++ )
		{
			seatOccupied[i] = -1;
		}
		seatOccupied[0] = 0;
		colorUsed = new boolean[10];
		colorList = new Color[10];
		colorList[0] = (ColorValue.PINK);
		colorList[1] = (ColorValue.DODGER_BLUE);
		colorList[2] = (ColorValue.DARK_CYAN);
		colorList[3] = (ColorValue.GOLD);
		colorList[4] = (ColorValue.OLIVE);
		colorList[5] = (ColorValue.GREEN);
		colorList[6] = (ColorValue.RED);
		colorList[7] = (ColorValue.SADDLE_BROWN);
		colorList[8] = (ColorValue.BLUE);
		colorList[9] = (ColorValue.DARK_VIOLET); 
		
		this.color = this.chooseAColor();
		
	}

	public void setOnline ( boolean b )
	{
		this.online = b;
	}
	public int findASeat ( int id )
	{
		for ( int  i = 0; i < 10 ; i ++ )
		{
			if ( seatOccupied[i] == -1 )
			{
				seatOccupied[i] = id;
				return i;
			}
		}
		return -1;
	}

	@Override
	public void run() 
	{
		gf.gameChairPanel.player1.setText(playerNameMap.get(0).name);
		while ( true )
		{
		try
		{
			ss = new ServerSocket(port);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		while ( online ) // the server is opening to accept client
		{
			try
			{
				
				Socket s = ss.accept();
				
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
				oos.writeObject(StringValue.VERSION);
				Object replayMessage = ois.readObject();
				if ( replayMessage instanceof LeaveMessage )
				{
					continue;
				}
				
				String playerName = (String) replayMessage;
				System.out.println("Server: get a player name - " + playerName);
				
				int seatLocation = findASeat( idCounter );
				PutPlayerNameOnTable.put(gf,seatLocation,playerName);
				UpdateGameLog.update(gf, playerName + StringValue.PLAYER_JOIN_ROOM);
				//gf.gameChairPanel.playerButtons[playerNameMap.size()].setText(playerName);
				sendToAllClient( new PlayerJoinMessage( idCounter, playerName , seatLocation ),idCounter);
				
				
				//playerInfoList.add(new PlayerInfo(idCounter,playerName));
				playerNameMap.put(idCounter, new PlayerInfo(idCounter,playerName,seatLocation));
				
				playerOosMap.put(idCounter, oos);
				
				
				//sendToAClient(idCounter, playerNameMap );
				
				//oos.writeObject(this.grm);
				oos.writeObject(new PlayerInfoListMessage(playerNameMap , idCounter ,this.chooseAColor()));
				
			
				
				Thread t = new Thread ( new MultiServerRunnable(this,idCounter,ois) );
				t.start();
				
				idCounter++;
				
				
			}
			catch ( Exception e )
			{
				e.printStackTrace();
			}
			
		}
		
		
		//prepare for gameEngine
		Iterator<Entry<Integer, PlayerInfo>> entries = playerNameMap.entrySet().iterator();
		int[] playerIDs = new int[playerNameMap.size()];
		int tmp = 0;
		while ( entries.hasNext() )
		{
			playerIDs[tmp] = entries.next().getKey();
			tmp++;
		}
		ge = new GameEngine(this,playerIDs);

		ge.start();
		this.online = true;
		}
	}
	
	public void gameStart()
	{
		this.online = false;
		try
		{
			this.ss.close();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	synchronized public void sendToAllClient ( Object o )
	{
		try
		{
			//Set<Entry<Integer,ObjectOutputStream>> oosSet = playerOosMap.entrySet();
			//for ( ObjectOutputStream oos : playerOoses )
			//{
			//	oos.writeObject(o);
			//}
			Iterator<Entry<Integer, ObjectOutputStream>> entries = playerOosMap.entrySet().iterator();
			while ( entries.hasNext() )
			{
				entries.next().getValue().writeObject(o);
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	synchronized public void sendToAllClient ( Object o, int id )
	{
		try
		{
			//for ( ObjectOutputStream oos : playerOoses )
			//{
			//	if ( !oos.equals(oosNotSend))
			//		oos.writeObject(o);
			//}
			Iterator<Entry<Integer, ObjectOutputStream>> entries = playerOosMap.entrySet().iterator();
			while ( entries.hasNext() )
			{
				Entry<Integer, ObjectOutputStream> thisEntry = entries.next();
				if ( (Integer)(thisEntry.getKey()) != id )
					thisEntry.getValue().writeObject(o);
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	
	synchronized public void sendToAClient( int id, Object o )
	{
		try
		{
			ObjectOutputStream oos = playerOosMap.get(id);
			if ( oos == null )
				System.out.println("null oos");
			oos.writeObject(o);
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
	}
	
	synchronized public boolean finishAction( int cardUsedPos)
	{
		if ( this.getYourTurn() )
		{
			
			this.setYourTurn(false);
			UpdateCountDown.update(gf,-1);
			timer.cancel();
			if ( ge.getCardStackSize() > 0 )
			{
				//sendToAClient(playerID,new DistributeHandCardMessage(gs.ge.drawACard()));
				UpdateHandCard.update(gf, ge.drawACard(),cardUsedPos);
				UpdateCardLeft.put(gf, ge.getCardStackSize());
				sendToAllClient(new CardLeftMessage( ge.getCardStackSize()));
			}
			else
			{
				UpdateHandCard.update(gf, null,cardUsedPos);
			}
			
			ge.notifySequenceLock();
			return true;
			
		}
		else return false;
		
		
	}
	public Color chooseAColor()
	{
		for ( int i = 0 ; i < 10 ; i ++ )
		{
			if ( !colorUsed[i] )
			{
				colorUsed[i] = true;
				return colorList[i];
			}
		}
		return null;
	}
	public void countDown()
	{
		
		if ( this.getYourTurn() )
		{
		
		timer = new Timer();
		
		timer.scheduleAtFixedRate(new TimerTask() {

			int interval = 20;
			public void run() 
			{
	        	
	         // System.err.println("Interval : "+interval);
	          if ( getYourTurn() )
	        	  UpdateCountDown.update(gf,interval);
	          
	      
	          if ( interval <= 0) 
	          {
				
	        	  if ( getYourTurn() )
	        	  {
	        		  synchronized(gf.entity.actionLock)
	        		  {  
	        			  System.err.println("timer acquire the action lock ");
	        			  // auto discard
	        			  int discardPos = -1;
	        			  for ( int i = 0 ; i < 4 ; i++)
	        			  {
	        				  if ( handCards[i] != null)
	        				  {
	        					  UpdateHandCard.update(gf,null, i);
	        					  discardPos = i;
	        					  break;
	        				  }
	        			  
	        			  }
	        			  if ( finishAction(discardPos) )
	        			  {
	        				  String logMessage = name + StringValue.TIME_OUT_MESSAGE;
	        				  UpdateGameLog.update(gf, logMessage);
	        				  sendToAllClient(new TimeOutMessage(logMessage));
	        			  }
	        		  }
	        	  
	        			
	        	  
				 }
	          }
	       
	          
	          interval--;
	        }
	    }, delay, period);
		
		}
	}
}
