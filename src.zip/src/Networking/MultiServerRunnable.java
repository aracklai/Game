package Networking;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import GameEngine.BanCard;
import GameEngine.RoadCard;
import GameEngine.ToolCard;
import GameEngine.UpdateGameGUI.AddConversation;
import GameEngine.UpdateGameGUI.PutPlayerNameOnTable;
import GameEngine.UpdateGameGUI.PutRoadCardOnMap;
import GameEngine.UpdateGameGUI.UpdateBanTable;
import GameEngine.UpdateGameGUI.UpdateCardLeft;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import GameEngine.UpdateGameGUI.UpdateTableInfo;

import Networking.Message.BanNotificationMessage;
import Networking.Message.BanRequestMessage;
import Networking.Message.CardLeftMessage;
import Networking.Message.ConversationMessage;
import Networking.Message.DiscardMessage;
import Networking.Message.DistributeHandCardMessage;
import Networking.Message.FinishActionMessage;
import Networking.Message.GameEndMessage;
import Networking.Message.LeaveMessage;
import Networking.Message.PutRoadCardOnMapNotificationMessage;
import Networking.Message.PutRoadCardOnMapRequestMessage;
import Networking.Message.RemoveACardFromMapNotificationMessage;
import Networking.Message.RemoveACardFromMapRequestMessage;
import Networking.Message.ResponseMessage;
import Networking.Message.SurrenderMessage;
import Networking.Message.SurrenderNotificationMessage;
import Networking.Message.TimeOutMessage;
import Networking.Message.UpdateBanTableMessage;
import Networking.Message.UseMapNotificationMessage;
import Networking.Message.UseMapRequestMessage;
import Resource.StringValue;

public class MultiServerRunnable implements Runnable {
	
	Host gs;
	public int playerID;
	public ObjectInputStream ois;
	public ObjectOutputStream oos;

	public MultiServerRunnable ( Host gs, int playerID, ObjectInputStream ois )
	{
		this.gs = gs;
		this.playerID = playerID;
		this.ois = ois;
	
	}
	
	public void run() {
		while ( true )
		{
			
			try
			{
				Object message = ois.readObject();
				
				if ( message instanceof PutRoadCardOnMapRequestMessage )
				{
					PutRoadCardOnMapRequestMessage prcomrm = (PutRoadCardOnMapRequestMessage) message;
					RoadCard rc = prcomrm.rc;
					int row = prcomrm.row;
					int column = prcomrm.column;
					
					System.out.println("Server got client put RoadCard on Map Request:");
					System.out.println("row:"+row+",column:"+column+",id:"+rc.id+",toUp:"+rc.toUp+",toDown:"+rc.toDown+",toLeft:"+rc.toLeft+",toRight:"+rc.toRight);
					if ( gs.ge.ms.putOnMap(row, column, rc))
					{
						gs.sendToAClient(playerID, new ResponseMessage(ResponseMessage.YES,0));
						PutRoadCardOnMapNotificationMessage promnm = new PutRoadCardOnMapNotificationMessage ( row , column ,rc,prcomrm.logMessage );
						gs.sendToAllClient( promnm);
						PutRoadCardOnMap.put(gs.gf, row, column, rc);
						UpdateGameLog.update(gs.gf, prcomrm.logMessage);
						
						
						
					}
					else
					{
						gs.sendToAClient(playerID, new ResponseMessage(ResponseMessage.NO,0));
					}
				}
				else if ( message instanceof FinishActionMessage )
				{
					//synchronized ( gs.ge.sequenceLock )
					//{
					//	gs.ge.sequenceLock.notify();
					//}
					FinishActionMessage fam = (FinishActionMessage) message;
					if ( gs.ge.getCardStackSize() > 0 )
					{
						gs.sendToAClient(playerID,new DistributeHandCardMessage(gs.ge.drawACard(),fam.cardUsedPos));
						
						UpdateCardLeft.put(gs.gf, gs.ge.getCardStackSize());
						gs.sendToAllClient(new CardLeftMessage( gs.ge.getCardStackSize()));
					}
					else
					{
						gs.sendToAClient(playerID, new DistributeHandCardMessage(null,fam.cardUsedPos));
					}
					gs.ge.notifySequenceLock();
					System.out.println("runnable send a notify");
				}
				else if ( message instanceof LeaveMessage )
				{
					
					LeaveMessage lm = (LeaveMessage) message;
					
					gs.playerNameMap.remove(lm.id);
					gs.sendToAllClient(message, lm.id);
					gs.playerOosMap.remove(lm.id);
					gs.seatOccupied[lm.seatLocation] = -1;
					gs.colorUsed[lm.seatLocation] = false;
					
					System.out.println("Host remove a client with id:" + lm.id);
					
					UpdateGameLog.update(gs.gf, lm.name + StringValue.PLAYER_LEAVE_ROOM);
					PutPlayerNameOnTable.put(gs.gf, lm.seatLocation, "");
					break;
					
				}
				else if ( message instanceof DiscardMessage )
				{
					DiscardMessage dm = (DiscardMessage) message;
					UpdateGameLog.update(gs.gf, dm.message);
					gs.sendToAllClient(message);
				}
				else if ( message instanceof RemoveACardFromMapRequestMessage )
				{
					RemoveACardFromMapRequestMessage racfmm = (RemoveACardFromMapRequestMessage) message;
					
					if ( gs.ge.ms.removeFromMap(racfmm.row, racfmm.column) )
					{
						RemoveACardFromMapNotificationMessage racfmnm = new RemoveACardFromMapNotificationMessage ( racfmm.row,racfmm.column,racfmm.message);
						gs.sendToAClient(playerID, new ResponseMessage(ResponseMessage.YES,0));
						gs.sendToAllClient(racfmnm);
						UpdateGameLog.update(gs.gf, racfmm.message);
						
					}
					else
					{
						gs.sendToAClient(playerID, new ResponseMessage(ResponseMessage.NO,0));
					}
				}
				else if (message instanceof ConversationMessage){
					gs.sendToAllClient(message, playerID);
					ConversationMessage cm = (ConversationMessage) message;
					AddConversation.add(gs.gf, ((ConversationMessage) message).getConversation(), cm.color);
				}
				else if ( message instanceof UseMapRequestMessage )
				{
					UseMapRequestMessage umrm = (UseMapRequestMessage) message;
					int id = gs.ge.ms.cards[umrm.row][umrm.column].id;
					UseMapNotificationMessage aumm = new UseMapNotificationMessage ( umrm.column,umrm.name);
					UpdateGameLog.update(gs.gf, aumm.message);
					
					gs.sendToAClient( this.playerID,new ResponseMessage ( ResponseMessage.YES , id) );
					gs.sendToAllClient( aumm);
					
				}
				else if ( message instanceof BanRequestMessage )
				{
					BanRequestMessage bqm = (BanRequestMessage) message;
					int playerId = gs.seatOccupied[bqm.seatLocation];
					Integer[] banArray = gs.ge.banMap.get(playerId);
					boolean valid = false;
					if ( bqm.instrument1 == BanCard.INSTRUMENT_PICKAXE || bqm.instrument2 == BanCard.INSTRUMENT_PICKAXE )
					{
						if ( bqm.function == ToolCard.FUNCTION_FORBIT)
						{
							valid = true;
							banArray[0]++;
							if ( bqm.seatLocation == 0)
								gs.pickaxeBanned ++;
						}
						else if ( bqm.function == ToolCard.FUNCTION_CLEAN )
						{
							if ( banArray[0] > 0)
							{
								valid = true;
								banArray[0]--;
								if ( bqm.seatLocation == 0){
									gs.pickaxeBanned--;
								}
							}
							else{
								//return;
							}
						}
						
						
					}
					
					
					if ( bqm.instrument1 == BanCard.INSTRUMENT_LAMP || bqm.instrument2 == BanCard.INSTRUMENT_LAMP )
					{
						if ( bqm.function == ToolCard.FUNCTION_FORBIT)
						{
							valid = true;
							banArray[1]++;
							if ( bqm.seatLocation == 0)
								gs.lampBanned++;
						}
						else if ( bqm.function == ToolCard.FUNCTION_CLEAN )
						{
							if ( banArray[1] > 0)
							{
								valid = true;
								banArray[1]--;
								if ( bqm.seatLocation == 0){
									gs.lampBanned--;
								}
							}
							else{
								//return;
							}
						}
					}
					
					
					if ( bqm.instrument1 == BanCard.INSTRUMENT_HELMET || bqm.instrument2 == BanCard.INSTRUMENT_HELMET )
					{
						if ( bqm.function == ToolCard.FUNCTION_FORBIT)
						{
							valid = true;
							banArray[2]++;
							if ( bqm.seatLocation == 0)
								gs.helmetBanned++;
						}
						else if ( bqm.function == ToolCard.FUNCTION_CLEAN )
						{
							if ( banArray[2] > 0)
							{
								valid = true;
								banArray[2]--;
								if ( bqm.seatLocation == 0){
									gs.helmetBanned--;
								}
							}
							else{
								//return;
							}
						}
					}
					if ( valid ){
					String message2;
					String bannerName = gs.playerNameMap.get(this.playerID).name;
					System.out.println("Runnable: BannerName:" + bannerName);
					String beBannerName = gs.playerNameMap.get( gs.seatOccupied[bqm.seatLocation]).name;
					System.out.println("Runnable: seatLocation:" + bqm.seatLocation);
					System.out.println("Runnable: function:" + bqm.function);
					if ( bqm.instrument2 == BanCard.INSTRUMENT_NULL  )
					{
						message2= bannerName + BanCard.getFunctionName(bqm.function) + beBannerName  + " on " +BanCard.getInstrumentName(bqm.instrument1) ;
					}
					else
					{
						message2= bannerName + BanCard.getFunctionName(bqm.function) + beBannerName + " on " +BanCard.getInstrumentName(bqm.instrument1) +", " + BanCard.getInstrumentName(bqm.instrument2) ;
					}
					
					//UpdateTableInfo.update(gs.gf,beBannerName , banArray[0], banArray[1],banArray[2] );
					
					UpdateGameLog.update( gs.gf, message2);
					UpdateBanTable.update(gs.gf, gs.seatOccupied[bqm.seatLocation], banArray[0], banArray[1], banArray[2]);
					if ( bqm.seatLocation == 0 )
					{
						System.err.println("Runnable: Ban Card apply on host" );
					//	gs.gf.gameInfoPanel.banStatus.setText("BAN:AXE("+gs.pickaxeBanned+"),LAMP("+gs.lampBanned+"),HELMET("+gs.helmetBanned+")");
						// tracy god implemnts
					}
					
						gs.sendToAClient(this.playerID, new ResponseMessage (ResponseMessage.YES,0));
						gs.sendToAllClient ( new UpdateBanTableMessage ( gs.seatOccupied[bqm.seatLocation], banArray[0], banArray[1], banArray[2]));
						gs.sendToAllClient( new BanNotificationMessage ( message2, banArray[0],banArray[1],banArray[2],playerId , this.playerID , beBannerName));
					}
					else
					{
						gs.sendToAClient(this.playerID, new ResponseMessage (ResponseMessage.NO,0));
					}
				
				}
				else if ( message instanceof SurrenderMessage )
				{
					
					if ( !gs.ge.gameEnded)
					{
						
					
						String surrenderName = gs.playerNameMap.get(this.playerID).name;
						int surrenderNumber = gs.ge.numberOfSurrender +1 ;
						String message2 = surrenderName + StringValue.SURRENDER_MESSAGE + String.valueOf(surrenderNumber);
						UpdateGameLog.update(gs.gf, message2);
						gs.sendToAllClient( new SurrenderNotificationMessage(message2) );
						gs.ge.incrementSurrender();
					}
				}
				else if ( message instanceof TimeOutMessage )
				{
					TimeOutMessage tom = (TimeOutMessage) message;
					
					UpdateGameLog.update(gs.gf, tom.logMessage);
					gs.sendToAllClient(tom);
				}
				else if ( message instanceof GameEndMessage )
				{
					GameEndMessage gem = (GameEndMessage) message;
					gs.ge.endGame(gem.message);
				}
				/*
				else if ( message instanceof DrawANewCardRequestMessage )
				{
					if ( gs.ge.getCardStackSize() > 0 )
					{
						gs.sendToAClient(playerID,new DistributeHandCardMessage(gs.ge.drawACard()));
						
						UpdateCardLeft.put(gs.gf, gs.ge.getCardStackSize());
						gs.sendToAllClient(new CardLeftMessage( gs.ge.getCardStackSize()));
					}
					else
					{
						gs.sendToAClient(playerID, new DistributeHandCardMessage(null));
					}
				}
				*/
				
			}
			catch ( Exception e )
			{
				e.printStackTrace();
			}
			
		}
		
	}

}
