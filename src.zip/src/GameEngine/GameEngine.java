package GameEngine;

import java.io.ObjectOutputStream;
import Resource.StringValue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Map.Entry;
import java.util.Random;

import javax.swing.JOptionPane;

import GameEngine.UpdateGameGUI.CollectHandCard;
import GameEngine.UpdateGameGUI.PutGoldAndStoneOnMap;
import GameEngine.UpdateGameGUI.ShowAllIdentities;
import GameEngine.UpdateGameGUI.ShowIdentity;
import GameEngine.UpdateGameGUI.UpdateCardLeft;
import GameEngine.UpdateGameGUI.UpdateGameLog;
import GameEngine.UpdateGameGUI.UpdateWhoTurn;
import Networking.Host;
import Networking.Message.AllIdentitiesMessage;
import Networking.Message.BuildRoadMessage;
import Networking.Message.CardLeftMessage;
import Networking.Message.FinishActionMessage;
import Networking.Message.GameEndMessage;
import Networking.Message.GameRuleMessage;
import Networking.Message.IdentityMessage;
import Networking.Message.PutGoldAndStoneOnMapMessage;
import Networking.Message.RefreshMessage;
import Networking.Message.YourTurnMessage;

public class GameEngine {
	
	public int numberOfGoodGuy;
	public int numberOfBadGuy;
	public int numberOfSurrender;
	
	public Object sequenceLock;
	//Object testLock;
	private ArrayList<Card> cards;
	
	public boolean gameEnded;
	public Host gs;
	
	int[] playerIDs;
	
	
	public MapStatus ms;
	public int currentPlayer;
	public HashMap<Integer, Integer[]> banMap;
	
	public HashMap<Integer,Integer> allIdenitiesMap;
	public GameEngine ( Host gs, int[] playerIDs )
	{
		this.gs = gs;
		this.numberOfSurrender = 0;
		this.numberOfBadGuy = 0;
		this.numberOfGoodGuy = 0;
		this.playerIDs = playerIDs;
		sequenceLock = new Object();
		//testLock = new Object();
		this.ms = new MapStatus( gs);
		this.banMap = new HashMap<Integer,Integer[]>();
		this.allIdenitiesMap = new HashMap <Integer,Integer>();
		for ( int i =  0; i < playerIDs.length ; i++ )
		{
			Integer[] banStatus = new Integer[3];
			banStatus[0] = new Integer(0);
			banStatus[1] = new Integer(0);
			banStatus[2] = new Integer(0);
			
			this.banMap.put(playerIDs[i], banStatus);
		}
		this.gameEnded = false;
	}
	synchronized public void incrementSurrender()
	{
		if ( !gameEnded )
		{
			numberOfSurrender++;
			System.err.println("IncrementSurrender: , numberOfgoodguy :" +numberOfGoodGuy+",number of surrender:"+ numberOfSurrender);
			if ( numberOfSurrender > numberOfGoodGuy/2 )
			{
				this.endGame( StringValue.BAD_GUY_WON_MESSAGE);
			}
		}
	}
	public void start()
	{
		gs.refresh();
		gs.sendToAllClient( new RefreshMessage());
		System.out.println("GameEngineStart");
		setStoneAndGoldLocation ();
		allocateIdentity();
		allocateCards();
		gs.sendToAllClient(new CardLeftMessage (cards.size() ));
		UpdateCardLeft.put(gs.gf, cards.size());
		currentPlayer = randomlyChooseTheStarter();
		//currentPlayer = 0;
		int previousSeatLocation = -1;
		while ( !gameEnded )
		{
			System.out.println("currentPlayer is :" + currentPlayer);
			
			UpdateWhoTurn.update(gs.gf,gs.playerNameMap.get(currentPlayer).seatLocation ,previousSeatLocation );
			gs.sendToAllClient( new YourTurnMessage(currentPlayer,gs.playerNameMap.get(currentPlayer).seatLocation,previousSeatLocation) );
			
			if ( currentPlayer == 0)
			{
				gs.setYourTurn(true);
				if ( gs.checkAllCardNull() )
				{
					this.endGame( StringValue.All_CARD_USED_MESSAGE);
					break;
				}
				else
				{	
					gs.timer.cancel();
					gs.countDown();
				}
				
			}
			else
			{
				gs.setYourTurn(false);
			}
			//System.out.println("my turn:"+ gs.yourTurn);
			
			
			try
			{
				synchronized (sequenceLock)
				{
					sequenceLock.wait();
				}
			}
			catch ( Exception e )
			{
				e.printStackTrace();
			}
	
			previousSeatLocation = gs.playerNameMap.get(currentPlayer).seatLocation;
			
			int tempLocation = previousSeatLocation;
			while ( true )
			{
				if ( tempLocation +1 == 10) 
				{
					tempLocation = 0;
					
				}
				else
				{
					tempLocation++;
					
				}
				
				
				if ( gs.seatOccupied[tempLocation] != -1)
				{
					currentPlayer = gs.seatOccupied[tempLocation];
					break;
				}
				
			}
			
			//if ( currentPlayer + 1  == playerIDs.length )
			//	currentPlayer = 0;
			//else currentPlayer++;
			
		}
		
	}
	/*
	private void allocateIdentity() {
		GameRuleMessage grm = setGameRule();
		this.numberOfGoodGuy = grm.numberOfGoodGuy;
		this.numberOfBadGuy = grm.numberOfBadGuy;
		System.err.println("AllocateIdentity: good guy:"+numberOfGoodGuy + ",badguy:"+numberOfBadGuy);
		int goodPlayerAllocated = 0;
		int badPlayerAllocated = 0;
		// set for host first
		if (this.numberOfBadGuy > 0 )
		{
			int randomForHost = new Random().nextInt(2);
			if ( randomForHost == IdentityMessage.GOOD_GUY )
			{
				gs.goodGuy = true;
				ShowIdentity.show(gs.gf,IdentityMessage.GOOD_GUY);
				goodPlayerAllocated++;
			}
			else 
			{
				ShowIdentity.show(gs.gf,IdentityMessage.BAD_GUY);
				badPlayerAllocated++;
			}
		}
		else
		{
			gs.goodGuy = true;
			ShowIdentity.show(gs.gf,IdentityMessage.GOOD_GUY);
			goodPlayerAllocated++;
		}
		
		Iterator<Entry<Integer, ObjectOutputStream>> entries = gs.playerOosMap.entrySet().iterator();
		
		while ( entries.hasNext() )
		{
			int clientId = entries.next().getKey();
			while ( true )
			{
				int random = new Random().nextInt(2);
				if ( random == 0 && goodPlayerAllocated < grm.numberOfGoodGuy  )
				{
					gs.sendToAClient( clientId, new IdentityMessage ( IdentityMessage.GOOD_GUY ));
					goodPlayerAllocated++;
					break;
				}
				else if ( random == 1 && badPlayerAllocated < grm.numberOfBadGuy )
				{
					gs.sendToAClient( clientId , new IdentityMessage ( IdentityMessage.BAD_GUY  ));
					badPlayerAllocated++;
					break;
				}
			}
			
		}
		
	}
	*/
	public void allocateIdentity()
	{
		GameRuleMessage grm = setGameRule();
		//this.numberOfGoodGuy = grm.numberOfGoodGuy;
		//this.numberOfBadGuy = grm.numberOfBadGuy;
		ArrayList<Integer> beforeSuffleList =  new ArrayList<Integer>();
		for ( int i = 0;  i < grm.numberOfGoodGuy ; i++)
		{
			beforeSuffleList.add(IdentityMessage.GOOD_GUY);
		}
		for ( int i = 0; i < grm.numberOfBadGuy ; i++ )
		{
			beforeSuffleList.add(IdentityMessage.BAD_GUY);
		}
		
		ArrayList<Integer> afterSuffleList = new ArrayList<Integer>();
		for ( int i = 0; i < grm.numberOfPlayer ;i ++)
		{
			int random = new Random().nextInt(beforeSuffleList.size());
			System.err.println("Character Allocated:" + beforeSuffleList.get(random));
			afterSuffleList.add(beforeSuffleList.get(random));
			beforeSuffleList.remove(random);
		}
		
		if ( afterSuffleList.get(0) == IdentityMessage.GOOD_GUY )
		{
			gs.goodGuy = true;
			this.numberOfGoodGuy++;
			ShowIdentity.show(gs.gf,IdentityMessage.GOOD_GUY);
		}
		else
		{
			this.numberOfBadGuy++;
			ShowIdentity.show(gs.gf,IdentityMessage.BAD_GUY);
		}
		this.allIdenitiesMap.put(0, afterSuffleList.get(0));
		Iterator<Entry<Integer, ObjectOutputStream>> entries = gs.playerOosMap.entrySet().iterator();
		
		int pos = 1;
		while ( entries.hasNext() )
		{
			
			int clientId = entries.next().getKey();
			int clientSeatLocation = gs.playerNameMap.get(clientId).seatLocation;
			if (afterSuffleList.get(pos) == IdentityMessage.GOOD_GUY )
			{
				this.numberOfGoodGuy++;
			}
			else
			{
				this.numberOfBadGuy++;
			}
			gs.sendToAClient( clientId, new IdentityMessage ( afterSuffleList.get(pos)));
			this.allIdenitiesMap.put(clientSeatLocation, afterSuffleList.get(pos));
			pos++;
		}
	}
	public void allocateCards()
	{
		cards = new SuffleCard().start();
		
		
		// for host
		for ( int j =  0; j < 4 ; j++ )
		{
			
			Card c = cards.get(0);
			gs.handCards[gs.numberOfHandCard] = c;
			CollectHandCard.collect(gs.gf, c.id, gs.numberOfHandCard);
			gs.numberOfHandCard++;
			cards.remove(0);
			
		}
		
		//for client
		Iterator<Entry<Integer, ObjectOutputStream>> entries = gs.playerOosMap.entrySet().iterator();
		while ( entries.hasNext() )
		{
			int clientId = entries.next().getKey();
			for ( int j =  0; j < 4 ; j++ )
			{
				gs.sendToAClient(clientId, cards.get(0));
				cards.remove(0);
			}
		}
		//for ( int i = 0; i < grm.numberOfPlayer; i++ )
		//{
			//ObjectOutputStream oos = gs.playerOoses.get(i);
			
		//}
	}
	private int randomlyChooseTheStarter()
	{
		
		int random;
		while (true)
		{
			random = new Random().nextInt(10);
			if ( gs.seatOccupied[random] != -1)
				break;
		}
		return gs.seatOccupied[random];
	}
	//private int chooseAnextPlayer()
	//{
		
	//}
	/*
	public void performPlayerAction( Object message )
	{
		if ( message instanceof BuildRoadMessage )
			//performBuildRoad();
		//else if ( message instanceof DiscardMessage )
		//	performDiscard();
		
		synchronized ( sequenceLock )
		{
			sequenceLock.notify();
		}
		
	}
	*/
	public void setStoneAndGoldLocation ()
	{
		RoadCard[] stoneAndGoldCards  = new RoadCard[3];
		RoadCard gold = new RoadCard( -1,1, false,false,true, true , true , true ,true);
		RoadCard stone1 = new RoadCard ( -2,1, false,true,true, false , false , true ,true);
		RoadCard stone2 = new RoadCard ( -3,1, false,true,false, true , false , true ,true);
		
		boolean goldPut = false;
		boolean stone1Put = false;
		boolean stone2Put = false;
		int numberOfCardPut = 0;
		while ( numberOfCardPut < 3 )
		{
			int random = new Random().nextInt(3);
			if ( random == 0 && !goldPut)
			{
				stoneAndGoldCards[numberOfCardPut] = gold;
				numberOfCardPut++;
				goldPut = true;
			}
			else if ( random == 1 && !stone1Put )
			{
				stoneAndGoldCards[numberOfCardPut] = stone1;
				numberOfCardPut++;
				stone1Put = true;
			}
			else if ( random == 2 && !stone2Put )
			{
				stoneAndGoldCards[numberOfCardPut] = stone2;
				numberOfCardPut++;
				stone2Put = true;
			}
		}
		ms.setUpGoldAndStone(stoneAndGoldCards);
		PutGoldAndStoneOnMap.put(gs.gf);
		gs.sendToAllClient(new PutGoldAndStoneOnMapMessage());		
		
	}
	
	public void notifySequenceLock ()
	{
		synchronized ( sequenceLock )
		{
			sequenceLock.notify();
		}
		
		System.out.println("Game engine :receive notify");
	}
	
	public Card drawACard()
	{
		Card card = cards.get(0);
		cards.remove(0);
		return card;
	}
	public int getCardStackSize()
	{
		return cards.size();
	}
	public GameRuleMessage setGameRule()
	{
		int numberOfPlayer = gs.playerNameMap.size();
		int numberOfBadGuy = -1;
		int numberOfGoodGuy = -1;
		if ( numberOfPlayer == 3 )
		{
			numberOfBadGuy = 1;
			numberOfGoodGuy = 2;
		}
		else if ( numberOfPlayer == 4 )
		{
			numberOfBadGuy = 1;
			numberOfGoodGuy = 3;
		}
		else if ( numberOfPlayer == 5 )
		{
			numberOfBadGuy = 2;
			numberOfGoodGuy = 4;
		}
		else if ( numberOfPlayer == 6 )
		{
			numberOfBadGuy = 2;
			numberOfGoodGuy = 5;
		}
		else if ( numberOfPlayer == 7 )
		{
			numberOfBadGuy = 3;
			numberOfGoodGuy = 5;
		}
		else if ( numberOfPlayer == 8 )
		{
			numberOfBadGuy = 3;
			numberOfGoodGuy = 6;
		}
		else if ( numberOfPlayer == 9 )
		{
			numberOfBadGuy = 3;
			numberOfGoodGuy = 7;
		}
		else if ( numberOfPlayer == 10 )
		{
			numberOfBadGuy = 4;
			numberOfGoodGuy = 7;
		}
		
		return new GameRuleMessage ( numberOfPlayer, numberOfGoodGuy, numberOfBadGuy );
	}
	public void endGame( String message )
	{
		this.gameEnded = true;
		gs.setYourTurn(false);
		gs.timer.cancel();
		this.notifySequenceLock();
		UpdateGameLog.update(gs.gf,message);
		ShowAllIdentities.show(gs.gf, new AllIdentitiesMessage(this.allIdenitiesMap));
		
		gs.sendToAllClient(new GameEndMessage(message, new AllIdentitiesMessage(this.allIdenitiesMap)));
	}
	
	

}
