package GameEngine.UpdateGameGUI;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import GUI.GameFrame;
import GameEngine.Card;
import Resource.ImageValue;

public class CollectHandCard {
	
	
	public static void collect( GameFrame gf, int cardId, int numberOfHandCard )
	{
		
			
			Image img = new ImageValue().getImage(cardId,ImageValue.HAND_CARD_DIMENSION);
			
			if ( numberOfHandCard == 0 )
				gf.handCardPanel.handCardButton1.setIcon(new ImageIcon(img));
			else if ( numberOfHandCard == 1 )
				gf.handCardPanel.handCardButton2.setIcon(new ImageIcon(img));
			else if ( numberOfHandCard == 2 )
				gf.handCardPanel.handCardButton3.setIcon(new ImageIcon(img));
			else if ( numberOfHandCard == 3 )
				gf.handCardPanel.handCardButton4.setIcon(new ImageIcon(img));
			
		
	}
}
