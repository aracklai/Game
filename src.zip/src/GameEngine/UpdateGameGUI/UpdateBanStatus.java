package GameEngine.UpdateGameGUI;

import GUI.GameFrame;

public class UpdateBanStatus {

	public static void update ( GameFrame gf ,String message )
	{
		//gf.gameInfoPanel.banStatus.setText(message);
	}
}
