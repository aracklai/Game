package GameEngine.UpdateGameGUI;

import GUI.GameFrame;

public class PutPlayerNameOnTable {
	
	public static void put ( GameFrame gf, int pos, String name )
	{
		gf.gameChairPanel.playerButtons[pos].setText(name);
	}

}
