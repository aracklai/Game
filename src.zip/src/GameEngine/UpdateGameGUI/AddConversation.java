package GameEngine.UpdateGameGUI;

import java.awt.Color;

import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import GUI.GameFrame;

public class AddConversation {
	
	public static void add(GameFrame gf, String	message, Color color){
		
		if(message.length() > 0){
			insert(message, gf.conversationPanel.doc, color);
			gf.conversationPanel.textLogArea.setCaretPosition(gf.conversationPanel.textLogArea.getDocument().getLength()); 
		}
	}
	
	
	private static void insert(String message, StyledDocument doc, Color color) {
		try {
			Style style = doc.addStyle("Style", null);
		    StyleConstants.setForeground(style, color);
			doc.insertString(doc.getLength(), message, style);
		} catch (BadLocationException e) {
			e.printStackTrace();
		}
	}

}
