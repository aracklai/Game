package GameEngine.UpdateGameGUI;

import java.awt.Color;
import java.awt.Font;

import GUI.GameFrame;

public class UpdateCountDown {
	
	public static void update ( GameFrame gf , int i )
	{
		if ( i != -1)
		{
			gf.gameInfoPanel.countDown.setFont(new Font("Arial", Font.BOLD, 20));
			gf.gameInfoPanel.countDown.setText(String.valueOf(i));
			if ( i <= 10 )
			{
				gf.gameInfoPanel.countDown.setForeground(  Color.RED);
			}
			else
			{
				gf.gameInfoPanel.countDown.setForeground(  Color.BLACK);
			}
		}
		else
			gf.gameInfoPanel.countDown.setText("");
	}

}
