package GameEngine.UpdateGameGUI;

import java.awt.Color;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

import GUI.GameFrame;
import Networking.Message.AllIdentitiesMessage;
import Networking.Message.IdentityMessage;

public class ShowAllIdentities {
	
	public static void show ( GameFrame gf , AllIdentitiesMessage aim )
	{
		Border redBorder = BorderFactory.createLineBorder(Color.RED, 3);
		Border greenBorder = BorderFactory.createLineBorder(Color.GREEN, 3);
		Iterator<Entry<Integer, Integer>> entries = aim.identitiesMap.entrySet().iterator();
		while ( entries.hasNext() )
		{
			Entry<Integer, Integer> entry = entries.next();
			if ( entry.getValue() == IdentityMessage.GOOD_GUY )
			{
				gf.gameChairPanel.playerButtons[entry.getKey()].setBorder( greenBorder);
			}
			else if ( entry.getValue() == IdentityMessage.BAD_GUY )
			{
				gf.gameChairPanel.playerButtons[entry.getKey()].setBorder( redBorder);
			}
		}
		
	}

}
