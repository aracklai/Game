package GameEngine.UpdateGameGUI;

import java.awt.Image;

import javax.swing.ImageIcon;

import GUI.GameFrame;
import GameEngine.RoadCard;
import Resource.ImageValue;

public class PutGoldAndStoneOnMap {
	
	public static void put( GameFrame gf )
	{
		ImageValue iv = new ImageValue();
		Image img = iv.getImage(-4,ImageValue.MAP_CARD_DIMENSION);
		gf.mapPanel.buttons[0][0].setIcon(new ImageIcon(img));
		gf.mapPanel.buttons[0][2].setIcon(new ImageIcon(img));
		gf.mapPanel.buttons[0][4].setIcon(new ImageIcon(img));
		
	}

}
