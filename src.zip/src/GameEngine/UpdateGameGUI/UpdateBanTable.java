package GameEngine.UpdateGameGUI;

import GUI.GameFrame;

public class UpdateBanTable {
	
	public static void update ( GameFrame gf ,int id, int axe, int lamp, int helmet )
	{
		gf.gameChairPanel.mtm.update(id,axe,lamp,helmet);
	}

}
