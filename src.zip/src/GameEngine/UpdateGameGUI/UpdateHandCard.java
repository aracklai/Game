package GameEngine.UpdateGameGUI;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import GUI.GameFrame;
import GameEngine.Card;
import Resource.ImageValue;

public class UpdateHandCard {

	public static void update( GameFrame gf , Card card ,int pos)
	{
		if ( pos == -1 )
			return;
		//Card theCardneedUpdate = null;
		JButton theButtonNeedUpdate = null;
		if ( pos ==  0)
		{
			gf.entity.handCards[0] = card;
			theButtonNeedUpdate= gf.handCardPanel.handCardButton1;
		}
		else if ( pos == 1)
		{
			gf.entity.handCards[1] = card;
			theButtonNeedUpdate= gf.handCardPanel.handCardButton2;
		}
		else if ( pos == 2 )
		{
			gf.entity.handCards[2] = card;
			theButtonNeedUpdate= gf.handCardPanel.handCardButton3;
		}
		else if ( pos == 3 )
		{
			gf.entity.handCards[3] = card;
			theButtonNeedUpdate= gf.handCardPanel.handCardButton4;
		}
		Image img;
		if ( card == null )
		{
			
			theButtonNeedUpdate.setIcon(null);
		}
		else
		{
			img = new ImageValue().getImage(card.id,ImageValue.HAND_CARD_DIMENSION);
			theButtonNeedUpdate.setIcon(new ImageIcon(img));
		}
		
		//theCardneedUpdate = card;
		
		
		/*
		if(gf.handCardPanel.A == true)
		{
			if ( card == null )
				gf.entity.handCards[0] = null;
			else
				gf.entity.handCards[0] = card;
			
			if ( img == null )
				gf.handCardPanel.handCardButton1.setIcon(null);
			else
				gf.handCardPanel.handCardButton1.setIcon(new ImageIcon(img));
		}
		else if(gf.handCardPanel.B == true)
		{
			if ( card == null )
				gf.entity.handCards[1] = null;
			else
				gf.entity.handCards[1] = card;
			
			if ( img == null )
				gf.handCardPanel.handCardButton2.setIcon(null);
			else
		  
				gf.handCardPanel.handCardButton2.setIcon(new ImageIcon(img));
		}
		else if(gf.handCardPanel.C == true)
		{
			if ( card == null )
				gf.entity.handCards[2] = null;
			else
				gf.entity.handCards[2] = card;
			if ( img == null )
				gf.handCardPanel.handCardButton3.setIcon(null);
			else
				gf.handCardPanel.handCardButton3.setIcon(new ImageIcon(img));		
		}
		else if(gf.handCardPanel.D == true)
		{
			if ( card == null )
				gf.entity.handCards[3] = null;
			else
				gf.entity.handCards[3] = card;
			if ( img == null )
				gf.handCardPanel.handCardButton4.setIcon(null);
			else 
				gf.handCardPanel.handCardButton4.setIcon(new ImageIcon(img));
		}
		else
		{
			if ( card == null )
			{
				
			}
			else
			{
				gf.entity.handCards[0] = card;
			}
			if ( img == null )
			{
				
			}
			else 
				gf.handCardPanel.handCardButton1.setIcon(new ImageIcon(img));
			
		}
		*/
	}
	
}
