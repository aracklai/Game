package GameEngine.UpdateGameGUI;

import GUI.GameFrame;
import GUI.GameInfoPanel;

public class UpdateCardLeft {

	
	public static void put(GameFrame gf, int num_of_card_left) {
		
		System.out.println("number of card left:" + num_of_card_left);
		gf.gameInfoPanel.cardLeftLablel.setText("Card Left: "+Integer.toString(num_of_card_left));
		
	}
}
