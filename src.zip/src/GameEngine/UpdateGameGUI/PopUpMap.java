package GameEngine.UpdateGameGUI;

import java.awt.Image;


import javax.swing.ImageIcon;

import javax.swing.JOptionPane;


import Resource.ImageValue;

public class PopUpMap {
	
	public static void popUp ( int id )
	{
		ImageValue iv = new ImageValue();
		Image im = iv.getImage(id, ImageValue.HAND_CARD_DIMENSION);
		//JLabel jl = new JLabel();
		//jl.setIcon(new ImageIcon(im));
		
		JOptionPane.showMessageDialog(null, new ImageIcon(im), "Investigation!" , JOptionPane.PLAIN_MESSAGE,null );
	}

}
