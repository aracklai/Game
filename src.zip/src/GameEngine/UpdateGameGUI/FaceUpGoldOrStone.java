package GameEngine.UpdateGameGUI;

import java.awt.Image;

import javax.swing.ImageIcon;

import GUI.GameFrame;
import Networking.Entity;
import Networking.Host;
import Resource.ImageValue;

public class FaceUpGoldOrStone {
	
	public static void faceUp ( Entity e, int id, int row, int column )
	{
		ImageValue iv = new ImageValue();
		Image img = iv.getImage(id,ImageValue.MAP_CARD_DIMENSION);
		e.gf.mapPanel.buttons[row][column].setIcon(new ImageIcon(img));
	}
}
