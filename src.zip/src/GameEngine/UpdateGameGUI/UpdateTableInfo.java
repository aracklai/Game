package GameEngine.UpdateGameGUI;

import GUI.GameFrame;

public class UpdateTableInfo {

	public static void update(GameFrame gf, String name, int axe, int lamp , int helmet ) {
		//gf.gameChairPanel.playerStatus.append(name+" :AXE("+axe+"),LAMP("+lamp+"),HELMET("+helmet+")\n");
		
	}


}
