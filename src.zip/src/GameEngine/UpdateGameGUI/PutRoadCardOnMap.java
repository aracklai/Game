package GameEngine.UpdateGameGUI;

import java.awt.Image;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import GUI.GameFrame;
import GameEngine.RoadCard;
import Resource.ImageValue;

public class PutRoadCardOnMap {

	
	//PutRoadCardOnMap ()
	
	public static void put( GameFrame gf, int row, int column,RoadCard rc )
	{
		ImageValue iv = new ImageValue();
		Image img = iv.getImage(rc.id,ImageValue.MAP_CARD_DIMENSION);
		
		gf.mapPanel.buttons[row][column].setIcon(new ImageIcon(img));
	}
}
