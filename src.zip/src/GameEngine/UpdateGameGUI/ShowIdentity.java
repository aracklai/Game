package GameEngine.UpdateGameGUI;

import javax.swing.ImageIcon;

import GUI.GameFrame;
import Networking.Message.IdentityMessage;
import Resource.ImageValue;

public class ShowIdentity {

	public static void show (  GameFrame gf ,int identity )
	{
		if ( identity == IdentityMessage.GOOD_GUY )
		{
			gf.gameInfoPanel.identityLabel.setIcon( new ImageIcon ( new ImageValue().getImage(-5, ImageValue.IDENTITY_CARD_DIMENSION)));
		}
		else if ( identity == IdentityMessage.BAD_GUY)
		{
			gf.gameInfoPanel.identityLabel.setIcon( new ImageIcon ( new ImageValue().getImage(-6, ImageValue.IDENTITY_CARD_DIMENSION)));
		}
			
	}
}
