package GameEngine.UpdateGameGUI;

import java.util.ArrayList;

import GUI.GameFrame;
import GUI.PlayerBanStatus;
import Networking.PlayerInfo;

public class AddBanTable {
	
	public static void add ( GameFrame gf , ArrayList<PlayerInfo> playerInfos )
	{
		gf.gameChairPanel.mtm.refresh();
		for ( int i = 0; i < playerInfos.size(); i++ )
			gf.gameChairPanel.mtm.addRow( new PlayerBanStatus(playerInfos.get(i).id,playerInfos.get(i).name));
	}

}
