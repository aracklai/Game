package GameEngine.UpdateGameGUI;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.UIManager;
import javax.swing.border.Border;

import GUI.GameFrame;

public class UpdateWhoTurn {

	
	public static void update ( GameFrame gf , int seatLocation , int previousSeatLocation  )
	{
		Border border = BorderFactory.createLineBorder(Color.RED, 3);
		
		
		
		gf.gameChairPanel.playerButtons[seatLocation].setBorder(border);
		
		if ( previousSeatLocation != -1 )
			gf.gameChairPanel.playerButtons[previousSeatLocation].setBorder(UIManager.getBorder("Button.border"));
		
	
	}
}
