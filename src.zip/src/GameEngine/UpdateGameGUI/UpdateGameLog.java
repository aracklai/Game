package GameEngine.UpdateGameGUI;

import GUI.GameFrame;

public class UpdateGameLog {

	
	public static void update ( GameFrame gf , String message )
	{
		gf.gameInfoPanel.gameLogTextArea.append(message+"\n");
		gf.gameInfoPanel.gameLogTextArea.setCaretPosition(gf.gameInfoPanel.gameLogTextArea.getDocument().getLength());
	}
}
