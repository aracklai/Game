package GameEngine.UpdateGameGUI;

import java.awt.Image;

import javax.swing.ImageIcon;

import GUI.GameFrame;
import GameEngine.RoadCard;
import Resource.ImageValue;

public class RemoveRoadCardFromMap {

	public static void remove( GameFrame gf, int row, int column )
	{
		
		
		gf.mapPanel.buttons[row][column].setIcon(null);
	}
}
