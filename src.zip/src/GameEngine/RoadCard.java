package GameEngine;

import java.io.Serializable;

public class RoadCard extends Card implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2840869152139979843L;
	public boolean deadRoad;
	public boolean canRotate;
	public boolean toRight;
	public boolean toLeft;
	public boolean toUp;
	public boolean toDown;
	public boolean faceDown;
	
	
	public RoadCard(int id, int quantity, boolean deadRoad, boolean canRotate, boolean toRight, boolean toLeft, boolean toUp, boolean toDown ,boolean faceDown) 
	{
		super( id, quantity);
		this.deadRoad = deadRoad;
		this.canRotate = canRotate;
		this.toRight = toRight;
		this.toLeft = toLeft;
		this.toUp = toUp;
		this.toDown = toDown;
		this.faceDown = faceDown;
		
		// TODO Auto-generated constructor stub
	}
	public RoadCard ( RoadCard rc )
	{
		super( rc.id, rc.quantity);
		this.deadRoad = rc.deadRoad;
		this.canRotate = rc.canRotate;
		this.toRight = rc.toRight;
		this.toLeft = rc.toLeft;
		this.toUp = rc.toUp;
		this.toDown = rc.toDown;
		this.faceDown = rc.faceDown;
	}

}
