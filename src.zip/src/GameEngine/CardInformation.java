package GameEngine;

import java.io.File;
import java.util.ArrayList;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class CardInformation {
	
	
	public ArrayList<Card> cards;
	
	
	public ArrayList<Card> get()
	{
		cards = new ArrayList<Card>();
		try
		{
			
			//File f = new File ( getClass().getResourceAsStream("/xmls/diggold_card_info.txt").toURI());
			//File f = new File ( getClass().getResourceAsStream("/xmls/diggold_card_info.txt"));
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(getClass().getResourceAsStream("/xmls/diggold_card_info.txt"));
			
			doc.getDocumentElement().normalize();
			
			NodeList roadCardNodeList= doc.getElementsByTagName("RoadCards");
			Node roadCardNode = roadCardNodeList.item(0);
			NodeList cardList = roadCardNode.getChildNodes();
			
			for (int temp = 0; temp < cardList.getLength(); temp++) {
				 
				
				Node cardNode = cardList.item(temp);
				
				
		 
				if (cardNode.getNodeType() == Node.ELEMENT_NODE) {
					System.out.println("\nCurrent Element :" + cardNode.getNodeName());
		 
					Element eElement = (Element) cardNode;
					
					int id = Integer.parseInt(eElement.getElementsByTagName("id").item(0).getTextContent());
					int quantity = Integer.parseInt( eElement.getElementsByTagName("quantity").item(0).getTextContent());
					boolean deadRoad = Boolean.parseBoolean(eElement.getElementsByTagName("deadRoad").item(0).getTextContent());
					boolean canRotate = Boolean.parseBoolean(eElement.getElementsByTagName("canRotate").item(0).getTextContent());
					boolean toRight = Boolean.parseBoolean(eElement.getElementsByTagName("toRight").item(0).getTextContent());
					boolean toLeft = Boolean.parseBoolean(eElement.getElementsByTagName("toLeft").item(0).getTextContent());
					boolean toUp = Boolean.parseBoolean(eElement.getElementsByTagName("toUp").item(0).getTextContent());
					boolean toDown =Boolean.parseBoolean(eElement.getElementsByTagName("toDown").item(0).getTextContent());
		 
					System.out.println("id :" + id );
					System.out.println("quantity: " + quantity);
					System.out.println("deadRoad: " + deadRoad);
					System.out.println("canRotate: " +  canRotate);
					System.out.println("toRight: " + toRight );
					System.out.println("toLeft: " + toLeft);
					System.out.println("toUp: " + toUp);
					System.out.println("toDown: " + toDown);
					
					int tmp = 0;
					while ( tmp < quantity )
					{
						cards.add ( new RoadCard(id,quantity,deadRoad,canRotate,toRight,toLeft,toUp,toDown,false));
						tmp++;
					}
					//System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
					//System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
					//System.out.println("Salary : " + eElement.getElementsByTagName("salary").item(0).getTextContent());
		 
				}
			}
			NodeList toolCardNodeList = doc.getElementsByTagName("ToolCards");
			Node toolCardNode = toolCardNodeList.item(0);
			NodeList cardList2 = toolCardNode.getChildNodes();
			
			for (int temp = 0; temp < cardList2.getLength(); temp++) {
				 
				
				Node cardNode = cardList2.item(temp);
				
				
		 
				if (cardNode.getNodeType() == Node.ELEMENT_NODE) {
					System.out.println("\nCurrent Element :" + cardNode.getNodeName());
		 
					Element eElement = (Element) cardNode;
					
					int id = Integer.parseInt(eElement.getElementsByTagName("id").item(0).getTextContent());
					int quantity = Integer.parseInt( eElement.getElementsByTagName("quantity").item(0).getTextContent());
					int function = Integer.parseInt( eElement.getElementsByTagName("function").item(0).getTextContent());
					int instrument1 = Integer.parseInt( eElement.getElementsByTagName("instrument1").item(0).getTextContent());
					int instrument2 = Integer.parseInt( eElement.getElementsByTagName("instrument2").item(0).getTextContent());
					System.out.println("id :" + id );
					System.out.println("quantity: " + quantity);
					System.out.println("function: " + function);
				
					
					int tmp = 0;
					while ( tmp < quantity )
					{
						if ( instrument1 != -1 )
						{
							cards.add ( new BanCard ( id ,quantity, function , instrument1,instrument2));
						}
						else
						{
							cards.add ( new ToolCard( id,quantity,function));
						}
						tmp++;
					}
					//System.out.println("Last Name : " + eElement.getElementsByTagName("lastname").item(0).getTextContent());
					//System.out.println("Nick Name : " + eElement.getElementsByTagName("nickname").item(0).getTextContent());
					//System.out.println("Salary : " + eElement.getElementsByTagName("salary").item(0).getTextContent());
		 
				}
			}
			

			

		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		
		return cards;
	}
}
