package GameEngine;

import java.io.Serializable;

public abstract class Card implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1426577353697762417L;
	//public final static int TYPE_ROAD = 0;
	//public final static int TYPE_TOOL = 1;
	//public final static int TYPE_STONE = 2;
	public final static int ENTRANCE_ID = 0;
	public final static int GOLD_ID = -1;
	public final static int STONE_ONE_ID = -2;
	public final static int STONE_TWO_ID = -3;
	
	
	public int id;
	
	public int quantity;
	
	
	
	public Card (  int id, int quantity )
	{
		
		
		this.id = id;
		this.quantity = quantity;
	}
}