package GameEngine;

import GUI.GameFrame;
import Resource.StringValue;
import GameEngine.UpdateGameGUI.FaceUpGoldOrStone;
import GameEngine.UpdateGameGUI.RemoveRoadCardFromMap;
import Networking.Host;
import Networking.Message.FaceUpGoldOrStoneOnMapMessage;
import Resource.ImageValue;



public class MapStatus {
	
	//PositionStatus[][] statues;
	public RoadCard [][] cards; 
	public Host host;
	//public GameFrame gf;
	public MapStatus( Host host)
	{
		//statues = new PositionStatus[9][5];
		this.host = host;
		cards = new RoadCard[9][5];
		RoadCard startingPoint = new RoadCard( 0,1, false,false,true, true , true , true ,false );
		cards[8][2] = startingPoint;
		//cards[8][]
		//Card = new Card ( 	
	}
	public void setUpGoldAndStone( RoadCard[] rcs )
	{
		cards[0][0] = rcs[0];
		cards[0][2] = rcs[1];
		cards[0][4] = rcs[2];
	}
	public boolean putOnMap ( int row , int column, RoadCard card)
	{
		if ( check( row , column , card))
		{
			// place the card
			cards[row][column] = new RoadCard(card);
			
			// check whether the card reach the stone or gold
			if ( !card.deadRoad && card.toUp && row == 1 && cards[row-1][column] != null && cards[row-1][column].faceDown )
			{
				cards[row-1][column].faceDown = false;
				FaceUpGoldOrStone.faceUp(host,cards[row-1][column].id,row-1,column);
				host.sendToAllClient(new FaceUpGoldOrStoneOnMapMessage(row-1,column,cards[row-1][column].id));
				if ( cards[row-1][column].id == -1 )
				{
					this.host.ge.endGame(StringValue.GOOD_GUY_WON_MESSAGE);
				}
				
			}
			if ( !card.deadRoad && card.toLeft && row == 0 && cards[row][column-1] != null && cards[row][column-1].faceDown )
			{
				cards[row][column-1].faceDown = false;
				if ( !cards[row][column-1].toRight )
				{
					System.out.println("MapStatus Rotate a Card");
					cards[row][column-1] = rotateRoadCard ( cards[row][column-1]);
				}
					
				FaceUpGoldOrStone.faceUp(host,cards[row][column-1].id,row,column-1);
				host.sendToAllClient(new FaceUpGoldOrStoneOnMapMessage(row,column-1,cards[row][column-1].id));
				if ( cards[row][column-1].id == -1 )
				{
					this.host.ge.endGame(StringValue.GOOD_GUY_WON_MESSAGE);
				}
			} 
			if ( !card.deadRoad && card.toRight && row == 0 && cards[row][column+1] != null && cards[row][column+1].faceDown )
			{
				cards[row][column+1].faceDown = false;
				if ( !cards[row][column+1].toLeft )
				{
					System.out.println("MapStatus Rotate a Card");
					cards[row][column+1] = rotateRoadCard ( cards[row][column+1]);
				}
				FaceUpGoldOrStone.faceUp(host,cards[row][column+1].id,row,column+1);
				host.sendToAllClient(new FaceUpGoldOrStoneOnMapMessage(row,column+1,cards[row][column+1].id));
				if ( cards[row][column+1].id == -1 )
				{
					this.host.ge.endGame(StringValue.GOOD_GUY_WON_MESSAGE);
				}
			}
			
			
			
			System.out.println( "toUp:"+cards[row][column].toUp + ",toDown:"+cards[row][column].toDown + ",toLeft:"+cards[row][column].toLeft +",toRight:"+ cards[row][column].toRight);
			for ( int i =  0; i < 9 ; i++ )
			{
				for ( int j  = 0; j < 5 ; j++ )
				{
					if ( cards[i][j] == null )
						System.out.print("*");
					else System.out.print("X");
				}
				System.out.println();
			}
			return true;
			
		}
		else return false;
	}
	
	public boolean removeFromMap ( int row ,int column )
	{
		if ( cards[row][column] == null )
		{
			System.out.println( "MapStatus-RemoveFromMap: the position you choose is null " );
			return false;
		}
		else
		{
			System.out.println( "MapStatus-RemoveFromMap: the position you choose is not null " );
		}
		
		cards[row][column] = null;
		RemoveRoadCardFromMap.remove ( host.gf,row , column);
		return true;
	}
	
	public boolean check ( int row, int column ,RoadCard card )
	{
		if ( cards[row][column] != null )
			return false;
		if ( row != 8 && isActive(row+1,column)  )
		{
			if ( card.toDown ^ cards[row+1][column].toUp)
			{
				System.out.println( "toDown != toUp" );
				System.out.println("toDown:"+card.toDown+",toUp:"+cards[row+1][column].toUp);
				return false;
			}
			else
			{
				System.out.println("toDown:"+card.toDown+",toUp:"+cards[row+1][column].toUp);
			}
		}
		if ( row != 0 && isActive(row-1,column)  )
		{
			if ( card.toUp ^ cards[row-1][column].toDown)
			{
				System.out.println( "toUp != toDown" );
				System.out.println("toUp:"+card.toUp+",toDown:"+cards[row-1][column].toDown);
				return false;
			}
			else
			{
				System.out.println("toUp:"+card.toUp+",toDown:"+cards[row-1][column].toDown);
			}
		}
		if ( column != 4 && isActive(row,column+1)  )
		{
			if ( card.toRight ^ cards[row][column+1].toLeft)
			{
				System.out.println( "toRight != toLeft" );
				System.out.println("toRight:"+card.toRight+",toLeft:"+cards[row][column+1].toLeft);
				return false;
			}
			else
			{
				System.out.println("toRight:"+card.toRight+",toLeft:"+cards[row][column+1].toLeft);
			}
		}
		if ( column != 0 && isActive(row,column-1)   )
		{
			
			if ( card.toLeft ^ cards[row][column-1].toRight)
			{
				System.out.println( "toLeft != toRight" );
				System.out.println("toLeft:"+card.toLeft+",toRight:"+cards[row][column-1].toRight);
				return false;
			}
			else
			{
				System.out.println("toLeft:"+card.toLeft+",toRight:"+cards[row][column-1].toRight);
			}
		}
		
		boolean[][] visited = new boolean[9][5];
		for ( int i = 0 ; i < 9 ; i ++ )
		{
			for ( int j  = 0; j < 5 ; j++ )
				visited[i][j] = false;
		}
		return  canAccessFromStart ( 8 , 2 , row , column , visited );
	
		
	}
	
	public boolean isActive ( int row , int column )
	{
		if ( cards[row][column] != null && !cards[row][column].faceDown)
			return true;
		else return false;
	}
	
	public boolean canAccessFromStart( int startRow , int startCol, int endRow, int endCol , boolean[][]visited )
	{
		
		if ( startRow == endRow && startCol == endCol )
			return true;
		
		
		if ( cards[startRow][startCol] == null )
			return false;
		else
		{
			System.out.println("set to be visisted" + startRow +"," + startCol);
			visited[startRow][startCol] = true;
			if ( !cards[startRow][startCol].deadRoad )
			{
				//System.out.println( visited[startRow][startCol-1] + "," + cards[startRow][startCol].toLeft + " ,"  +startCol);
				if ( cards[startRow][startCol].toUp && startRow != 0 && !visited[startRow-1][startCol]   )
	
				{
					if ( canAccessFromStart( startRow-1,startCol,endRow,endCol,visited ))
						return true;
				}
				if ( cards[startRow][startCol].toDown && startRow != 8 && !visited[startRow+1][startCol]   )
				{
					if ( canAccessFromStart (startRow+1 , startCol , endRow,endCol,visited ))
						return true;
				}
				
				if ( cards[startRow][startCol].toLeft && startCol != 0 && !visited[startRow][startCol-1]  )
				{
					if ( canAccessFromStart ( startRow , startCol-1, endRow,endCol,visited)  )
						return true;
				}
				if ( cards[startRow][startCol].toRight && startCol != 4 && !visited[startRow][startCol+1])
				{
					if ( canAccessFromStart ( startRow, startCol +1 , endRow,endCol,visited))
						return true;
				}
				
			}
			return false;
			
		}
	}
	private RoadCard rotateRoadCard (RoadCard rc) {
		
		boolean temp;
		
		if(rc.toDown != rc.toUp){
			temp = rc.toDown;
			rc.toDown = rc.toUp;
			rc.toUp = temp;
		}
		
		if(rc.toLeft != rc.toRight){
			temp = rc.toLeft;
			rc.toLeft = rc.toRight;
			rc.toRight = temp;
		}
		rc.id =  rc.id * 100;
				
		return rc;	
	}
}
