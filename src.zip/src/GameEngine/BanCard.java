package GameEngine;

import Resource.StringValue;

public class BanCard extends ToolCard {
	
	/**
	 * 
	 */
	public final static int INSTRUMENT_HELMET = 0;
	public final static int INSTRUMENT_PICKAXE = 1;
	public final static int INSTRUMENT_LAMP = 2;
	public final static int INSTRUMENT_NULL = -1;
	
	private static final long serialVersionUID = -1683655741246865647L;
	public int instrument1;
	public int instrument2;
	public BanCard ( int id, int quantity, int function , int instrument1, int instrument2 )
	{
		super ( id , quantity , function);
		this.instrument1 = instrument1;
		this.instrument2 = instrument2;
	}
	
	public static String getInstrumentName( int id )
	{
		if ( id == BanCard.INSTRUMENT_HELMET )
			return StringValue.HELMET;
		else if ( id == BanCard.INSTRUMENT_LAMP)
			return StringValue.LAMP;
		else if ( id == BanCard.INSTRUMENT_PICKAXE)
			return StringValue.PICKAXE;
		
		return null;
	}
	
	public static String getFunctionName ( int id )
	{
		if ( id == ToolCard.FUNCTION_CLEAN )
			return StringValue.SOLVE;
		else if ( id == ToolCard.FUNCTION_FORBIT )
			return StringValue.BAN;
		
		return null;
	}

}
