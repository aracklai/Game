package GameEngine;

import java.util.ArrayList;
import java.util.Random;

import Resource.ImageValue;

public class SuffleCard {
	
	ArrayList<Card> cardsBeforeSuffle;
	ArrayList<Card> cardsAfterSuffle;
	boolean roadCardInserted[];
	boolean toolCardInserted[];
	
	public SuffleCard()
	{
		
		//roadCardInserted = new boolean[22]; // should be false initial
		//toolCardInserted = new boolean[22]; // should be false
		//start();
	}
	/*
	public Card[] start()
	{
		int numberOfCardInserted = 0;
		int numberOfRoadCardInserted = 0;
		int numberOfToolCardInserted = 0;
		
		while ( numberOfCardInserted < 44 )
		{
			int random = new Random().nextInt(2); // 0 is Road_type, 1 is tool
			if ( random == ImageValue.TYPE_ROAD )
			{
				while ( numberOfRoadCardInserted < 22 )
				{
					int id = new Random().nextInt(22);
					if ( roadCardInserted[id] == false )
					{
						//cards[numberOfCardInserted] = new Card ( id , ImageValue.TYPE_ROAD );
						roadCardInserted[id] = true;
						numberOfCardInserted++;
						numberOfRoadCardInserted++;
						break;
					}
				}
				
			}
			else if ( random == ImageValue.TYPE_TOOL )
			{
				while ( numberOfToolCardInserted < 22 )
				{
					int id = new Random().nextInt(22);
					if ( toolCardInserted[id] == false )
					{
						//cards[numberOfCardInserted] = new Card ( id , ImageValue.TYPE_TOOL );
						toolCardInserted[id] = true;
						numberOfCardInserted++;
						numberOfToolCardInserted++;
						break;
					}
				}
			}
		}
		//return cards;
		
	}
	*/
	public ArrayList<Card> start()
	{
		CardInformation cif = new CardInformation();
		cardsBeforeSuffle = cif.get();
		cardsAfterSuffle = new ArrayList<Card>();
		int numberOfCard = cardsBeforeSuffle.size();
		int tmp = 0;
		while ( tmp < numberOfCard )
		{
			int random = new Random().nextInt(cardsBeforeSuffle.size());
			cardsAfterSuffle.add(tmp,cardsBeforeSuffle.get(random));
			cardsBeforeSuffle.remove(random);
			tmp++;
		}
		return cardsAfterSuffle;
	}
	
	

}
