package GameEngine;

import java.io.Serializable;

public class ToolCard extends Card implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3432502718777361448L;

	public static final int FUNCTION_FORBIT = 0;
	public static final int FUNCTION_CLEAN = 1;
	public static final int FUNCTION_WATCH = 2;
	public static final int FUNCTION_EXPLODE = 3;
	//public static final int 
	
	public int function;
	public ToolCard ( int id, int quantity ,int function )
	{
		super(id,quantity);
		this.function = function;
	}

}
